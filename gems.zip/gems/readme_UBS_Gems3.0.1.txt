This readme file is maintained by IBTS Component Engineering (CE) - Enterprise Messaging Technologies (MsgTech). It
documents changes made by CE MsgTech to the base Gems product supplied by the Vendor.

Date		Vendor Gems Version	UBS Version	Changes
28/6/2007	2.4			2.4.1		Include Debug=false in gems.props
							Include ssl.debug_trace as sample entry in servers.xml
19/7/2007	2.4.a			2.4.a.1		Improved SSL debug trace by setting the following in servers.xml:
								<SSLParam name="com.tibco.tibjms.ssl.trace" type="boolean" value="true" />
								<SSLParam name="com.tibco.tibjms.ssl.debug_trace" type="boolean" value="false" />
04/8/2008	3.0			3.0.1		Re-distributing TIBCO EMS java libraries along with GEMS install. 
							changes are made to rungems.bat to pick these in CLASSPATH settings
							With this change, EMS install is no longer a pre-requisite for GEMS installation
