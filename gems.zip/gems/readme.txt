Graphical Administration Tool for EMS4.x, EMS 5.x
=================================================

Gems v3.0
---------

New Features:

- Support for EMS5.0:
	- Channels Info panel
	- Stores(File), Stores(DB) Info panel
	- Server Info: isMulticastEnabled, MulticastStatisticsInterval, StoresFile, ChannelsFile
	- Queue Info: Store, isStoreInherited
	- Topic Info: Store, isStoreInherited, Channel, isChannelInherited, isMulticastEnabled
	- Connection Info: UncommittedCount, UncommittedSize
	- Consumer Info: Multicast
	- Route Info: BacklogCount, BacklogSize
- Copy selected messages in Queue Browser window to another destination/server
- Destroy selected messages in Queue Browser window
- Purge multiple queues/topics
- Service (request/reply) monitoring (see servers.xml)
- View Text messages as XML via right mouse click popup menu
- View Bytes messages as text via right mouse click popup menu
- Custom column widths are maintained between displays
- Save tabular data to CSV file via right mouse click popup menu
- View original message from $sys.monitor messages
- New configurable properties (see gems.props):
	MaxDisplayBytes - Maximum display size for bytes messages

Gems v2.4
---------

New Features:

- Support for new EMS4.4 properties:
	- PendingMsgCount, PendingMsgSize and selector on consumer properties
	- Prefetch, MaxMsgs and OverflowPolicy on topic properties
	- isRouted and getRouteName queue properties
- SSL connectivity (see servers.xml)
- Cut and Paste on edit menu and right mouse click popup menu
- Selector wizard for queue browsing by message timestamp
- Options editor in Queue Browser, Durable Browser and Topic Subscriber
- Column sorting on Server Info and Message Browser panels
- Route Management and highlighting for disconnected routes.
- Routing info added to Queues Info display
- PermType setting in gems.props to show destinations by permanence type (default; no temps)
- Tree icons and custom icons configurable in servers.xml

Gems v2.3
---------

New Features:

- Support for new EMS4.3 properties
- Destination and Administration permissions management
- Bridge management
- Queue and Topic Monitor
- View only mode
- Improved bridge and route details
- AutoConnect attribute in servers.xml
- Customizable tree view in servers.xml e.g. to group servers in regions or by environment
- Pending message sizes highlighted in red when reaches 80% of MaxBytes or MaxMsgs limit

Gems v2.2
---------

New Features:

- Storage Info display tab
- Set server properties dialog
- Set destination properties dialog

Gems v2.1
---------

New Features:

- Main Server Monitor display with configurable limit minding and colour highlighting
- User management; create, update, destroy user
- Durable management; create, destroy, purge, browse pending messages
- Automatic display refresh
- Column sorting on display panel
- Save/load text messages to/from file
- Loads server connection details and limits from servers.xml file
- Display properties configuration file (gems.props)
- Destroy a client's EMS connection


Gems v1.0
---------

Supports:
 
- Multiple EMS server connections
- Displays configuration and statistics for topics, queues, ACLs, routes, connections, durables, groups, producers, transactions, transports, users.
- Queue management; create, destroy, purge, browse messages, send text messages
- Topic management; create, destroy, purge, subscribe to messages, publish text messages


Requires:
---------

- Tibco EMS 4.x, EMS 5.x
- JRE 1.5 or higher


Support:
--------

THIS TOOL IS NOT AN OFFICIAL PRODUCT OF TIBCO.
IT IS NOT SUPPORTED BY TIBCO.
TIBCO IS NOT RESPONSIBLE FOR ANY LOSS OR ISSUE RESULTING FROM THE USE OF THIS 
TOOL.

Only the author may provide non-immediate or non-complete support.

Please, send any requests, comments, suggestions, issues to the author:

Richard Lawrence (rlawrenc@tibco.com)
