TIBEMS_ROOT=/app/product/tibco/ems

## You should not need to change the text below

TIBEMS_JAVA=$TIBEMS_ROOT/clients/java

CLASSPATH=$TIBEMS_JAVA/jms.jar:$TIBEMS_JAVA/jndi.jar
CLASSPATH=$TIBEMS_JAVA/jta-spec1_0_1.jar:$CLASSPATH
CLASSPATH=$TIBEMS_JAVA/jcert.jar:$TIBEMS_JAVA/jnet.jar:$TIBEMS_JAVA/jsse.jar:$CLASSPATH
CLASSPATH=Gems.jar:$TIBEMS_JAVA/tibjms.jar:$TIBEMS_JAVA/tibcrypt.jar:$TIBEMS_JAVA/tibjmsadmin.jar:$CLASSPATH

nohup java -classpath $CLASSPATH com.tibco.gems.Gems gems.props > gems.out 2>&1 &
PPID=$!

echo "GEMS launched in background (PID=$PPID)"
