--DATABASE RESET/SETUP SCRIPT
USE ponal;
go

-- DROP CONSTRAINTS
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID(N'dbo.equipo'))
BEGIN
	IF OBJECT_ID('fk_equipo_marca', 'F') IS NOT NULL
		ALTER TABLE [dbo].equipo DROP CONSTRAINT fk_equipo_marca
	IF OBJECT_ID('fk_equipo_linea', 'F') IS NOT NULL
		ALTER TABLE [dbo].equipo DROP CONSTRAINT fk_equipo_linea
	IF OBJECT_ID('fk_equipo_modelo', 'F') IS NOT NULL
		ALTER TABLE [dbo].equipo DROP CONSTRAINT fk_equipo_modelo
END

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID(N'dbo.asignacion'))
BEGIN
	IF OBJECT_ID('fk_asignacion_equipo', 'F') IS NOT NULL
		ALTER TABLE [dbo].asignacion DROP CONSTRAINT fk_asignacion_equipo

	IF OBJECT_ID('fk_asignacion_unidad', 'F') IS NOT NULL
		ALTER TABLE [dbo].asignacion DROP CONSTRAINT fk_asignacion_unidad
END

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID(N'dbo.unidad'))
BEGIN
	IF OBJECT_ID('fk_unidad_marca', 'F') IS NOT NULL
		ALTER TABLE [dbo].unidad DROP CONSTRAINT fk_unidad_marca
	IF OBJECT_ID('fk_unidad_linea', 'F') IS NOT NULL
		ALTER TABLE [dbo].unidad DROP CONSTRAINT fk_unidad_linea
END

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID(N'dbo.ubicacion'))
BEGIN
	IF OBJECT_ID('fk_ubicacion_unidad', 'F') IS NOT NULL
		ALTER TABLE [dbo].ubicacion DROP CONSTRAINT fk_ubicacion_unidad
END

-- CREATE TABLES
IF OBJECT_ID('dbo.modelo', 'U') IS NOT NULL
	DROP TABLE [dbo].modelo

CREATE TABLE [dbo].modelo
  (
     id_modelo   CHAR(10) NOT NULL,
     cod_modelo  VARCHAR(50),
     desc_modelo VARCHAR(100) NOT NULL,
     PRIMARY KEY (id_modelo),
     UNIQUE (id_modelo)
  )

IF OBJECT_ID('dbo.marca', 'U') IS NOT NULL
	DROP TABLE [dbo].marca

CREATE TABLE [dbo].marca
  (
     id_marca      CHAR(10) NOT NULL,
     desc_marca    VARCHAR(100) NOT NULL,
     cod_marca_cat VARCHAR(20),
     PRIMARY KEY (id_marca),
     UNIQUE (id_marca)
  )

IF OBJECT_ID('dbo.linea', 'U') IS NOT NULL
	DROP TABLE [dbo].linea

CREATE TABLE [dbo].linea
  (
     id_linea      CHAR(10) NOT NULL,
     desc_linea    VARCHAR(100) NOT NULL,
     cod_linea_cat VARCHAR(20),
     PRIMARY KEY (id_linea),
     UNIQUE (id_linea)
  )


IF OBJECT_ID('dbo.equipo', 'U') IS NOT NULL
	DROP TABLE [dbo].equipo

CREATE TABLE [dbo].equipo
  (
     id_equipo     		CHAR(20),
     id_runt       		CHAR(20),
     idm_equipo    		CHAR(10),
     id_marca      		CHAR(10),
     id_linea      		CHAR(10),
     id_modelo     		CHAR(10),
     tipomaquin  		  CHAR(10),
     seriemaq    		  CHAR(20),
     motor       		  CHAR(20),
     chasis        		CHAR(20),
     id_unidad_vigente CHAR(20),
     tipounidad    		CHAR(2),
     orden_trabajo 		CHAR(10),
     contrato      		CHAR(20),
     usuario       		CHAR(20),
     fecha         		DATE,
     hora          		TIME,
     -- Define si reporta o no a la policia
     reportar      		CHAR(1),
     --Estado de las transmisiones
     estado        		CHAR(1),
     ultima_fecha  		DATE,
     PRIMARY KEY (id_equipo),
     UNIQUE (id_equipo)
  )


IF OBJECT_ID('dbo.unidad', 'U') IS NOT NULL
	DROP TABLE [dbo].unidad

CREATE TABLE [dbo].unidad
  (
     id_unidad         CHAR(30),
     serie_dispositivo CHAR(30),
     id_marca          CHAR(10),
     id_linea          CHAR(10),
     imei              CHAR(50),
     tarjeta_sim       CHAR(50),
     numero_movil      CHAR(20),
     opera_movil       CHAR(30),
     opera_satel       CHAR(30),
     observacion       CHAR(50),
     fecunidad         CHAR(19),
     usuario           CHAR(20),
     fecha             DATE,
     hora              TIME,
     PRIMARY KEY (id_unidad),
     UNIQUE (id_unidad)
  )

IF OBJECT_ID('dbo.asignacion', 'U') IS NOT NULL
	DROP TABLE [dbo].asignacion

CREATE TABLE [dbo].asignacion
  (
     id_equipo         CHAR(20),
     id_unidad         CHAR(30),
     docinstal         CHAR(20),
     estadouni         CHAR(1),
     usuario           CHAR(20),
     fecha             DATE,
     hora              TIME,
     PRIMARY KEY ( id_equipo, id_unidad ),
     UNIQUE ( id_equipo, id_unidad )
  )

IF OBJECT_ID('dbo.ubicacion', 'U') IS NOT NULL
	DROP TABLE [dbo].ubicacion

CREATE TABLE [dbo].ubicacion
  (
     id_trama			    CHAR(20),
     id_unidad			  CHAR(30),
     tipo_transmision CHAR(20),
     longitud		    	CHAR(20),
     latitud			    CHAR(20),
     velocidad		  	CHAR(20),
     direccion		  	CHAR(20),
     fechaGPS         DATE,
     evento				    CHAR(20),
     ignicion		  	  CHAR(20),
     pip				      CHAR(20),
     puerto			  	  CHAR(20),
     status			    	CHAR(1),
     odometro		  	  CHAR(20)
     PRIMARY KEY ( id_trama ),
     UNIQUE ( id_trama )
  )


IF OBJECT_ID('dbo.lista_correo', 'U') IS NOT NULL
	DROP TABLE [dbo].lista_correo

CREATE TABLE [dbo].lista_correo
  (
     id_lista   	     INT NOT NULL IDENTITY,
     proceso           CHAR(4),
     tipo_notificacion CHAR(10),
     email_remitente   CHAR(200),
     asunto            CHAR(200),
     email_destino     CHAR(200),
     email_copia       CHAR(200),
     usuariop_mod      CHAR(10),
     fecha_mod         DATE,
     PRIMARY KEY ( id_lista ),
     UNIQUE ( id_lista )
  )

IF OBJECT_ID('dbo.texto_certificado', 'U') IS NOT NULL
	DROP TABLE [dbo].texto_certificado

CREATE TABLE [dbo].texto_certificado
  (
     secuencia         INT,
     texto_certificado VARCHAR(1000),
     usuario_txt       CHAR(20),
     fecha_txt         DATE,
     hora_txt          TIME,
     PRIMARY KEY (secuencia),
     UNIQUE (secuencia)
  )

-- ADD CONSTRAINTS
ALTER TABLE [dbo].equipo
ADD CONSTRAINT fk_equipo_marca FOREIGN KEY (id_marca)
	REFERENCES marca (id_marca)
	ON DELETE CASCADE
	ON UPDATE CASCADE;

ALTER TABLE [dbo].equipo
ADD CONSTRAINT fk_equipo_linea FOREIGN KEY (id_linea)
	REFERENCES linea (id_linea)
	ON DELETE CASCADE
	ON UPDATE CASCADE;

ALTER TABLE [dbo].equipo
ADD CONSTRAINT fk_equipo_modelo FOREIGN KEY (id_modelo)
	REFERENCES modelo (id_modelo)
	ON DELETE CASCADE
		ON UPDATE CASCADE;

ALTER TABLE [dbo].unidad
ADD CONSTRAINT fk_unidad_marca FOREIGN KEY (id_marca)
	REFERENCES marca (id_marca)
	ON DELETE CASCADE
	ON UPDATE CASCADE;

ALTER TABLE [dbo].unidad
ADD CONSTRAINT fk_unidad_linea FOREIGN KEY (id_linea)
	REFERENCES linea (id_linea)
	ON DELETE CASCADE
	ON UPDATE CASCADE;


ALTER TABLE [dbo].asignacion
ADD CONSTRAINT fk_asignacion_equipo FOREIGN KEY (id_equipo)
	REFERENCES equipo (id_equipo)
	ON DELETE CASCADE
	ON UPDATE CASCADE;

ALTER TABLE [dbo].asignacion
ADD CONSTRAINT fk_asignacion_unidad FOREIGN KEY (id_unidad)
	REFERENCES unidad (id_unidad);

ALTER TABLE [dbo].ubicacion
ADD CONSTRAINT fk_ubicacion_unidad FOREIGN KEY (id_unidad)
	REFERENCES unidad (id_unidad)
	ON DELETE CASCADE
	ON UPDATE CASCADE;

