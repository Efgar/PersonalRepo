 --DATABASE RESET/SETUP SCRIPT
USE ponal;

go

-- DROP CONSTRAINTS
IF EXISTS (SELECT 1
           FROM   sys.foreign_keys
           WHERE  parent_object_id = Object_id('dbo.equipo'))
  BEGIN
      IF Object_id('fk_equipo_marca', 'F') IS NOT NULL
        ALTER TABLE [dbo].equipo
          DROP CONSTRAINT fk_equipo_marca

      IF Object_id('fk_equipo_linea', 'F') IS NOT NULL
        ALTER TABLE [dbo].equipo
          DROP CONSTRAINT fk_equipo_linea

      IF Object_id('fk_equipo_modelo', 'F') IS NOT NULL
        ALTER TABLE [dbo].equipo
          DROP CONSTRAINT fk_equipo_modelo

      IF Object_id('fk_equipo_asignacion', 'F') IS NOT NULL
        ALTER TABLE [dbo].equipo
          DROP CONSTRAINT fk_equipo_asignacion
  END

IF EXISTS (SELECT 1
           FROM   sys.foreign_keys
           WHERE  parent_object_id = Object_id('dbo.asignacion'))
  BEGIN
      IF Object_id('fk_asignacion_equipo', 'F') IS NOT NULL
        ALTER TABLE [dbo].asignacion
          DROP CONSTRAINT fk_asignacion_equipo

      IF Object_id('fk_asignacion_unidad', 'F') IS NOT NULL
        ALTER TABLE [dbo].asignacion
          DROP CONSTRAINT fk_asignacion_unidad
  END

IF EXISTS (SELECT 1
           FROM   sys.foreign_keys
           WHERE  parent_object_id = Object_id('dbo.unidad'))
  BEGIN
      IF Object_id('fk_unidad_marca', 'F') IS NOT NULL
        ALTER TABLE [dbo].unidad
          DROP CONSTRAINT fk_unidad_marca

      IF Object_id('fk_unidad_linea', 'F') IS NOT NULL
        ALTER TABLE [dbo].unidad
          DROP CONSTRAINT fk_unidad_linea
  END

IF EXISTS (SELECT 1
           FROM   sys.foreign_keys
           WHERE  parent_object_id = Object_id('dbo.ubicacion'))
  BEGIN
      IF Object_id('fk_ubicacion_unidad', 'F') IS NOT NULL
        ALTER TABLE [dbo].ubicacion
          DROP CONSTRAINT fk_ubicacion_unidad
  END

-- CREATE TABLES
IF Object_id('dbo.modelo', 'U') IS NOT NULL
  DROP TABLE [dbo].modelo

CREATE TABLE [dbo].modelo
  (
     id_modelo   VARCHAR(10) NOT NULL,
     cod_modelo  VARCHAR(50),
     desc_modelo VARCHAR(100) NOT NULL,
     PRIMARY KEY (id_modelo),
     UNIQUE (id_modelo)
  )

IF Object_id('dbo.marca', 'U') IS NOT NULL
  DROP TABLE [dbo].marca

CREATE TABLE [dbo].marca
  (
     id_marca      VARCHAR(10) NOT NULL,
     desc_marca    VARCHAR(100) NOT NULL,
     cod_marca_cat VARCHAR(20),
     PRIMARY KEY (id_marca),
     UNIQUE (id_marca)
  )

IF Object_id('dbo.linea', 'U') IS NOT NULL
  DROP TABLE [dbo].linea

CREATE TABLE [dbo].linea
  (
     id_linea      VARCHAR(10) NOT NULL,
     desc_linea    VARCHAR(100) NOT NULL,
     cod_linea_cat VARCHAR(20),
     PRIMARY KEY (id_linea),
     UNIQUE (id_linea)
  )

IF Object_id('dbo.equipo', 'U') IS NOT NULL
  DROP TABLE [dbo].equipo

CREATE TABLE [dbo].equipo
  (
     id_equipo          VARCHAR(20),
     id_runt            VARCHAR(20),
     idm_equipo         VARCHAR(10),
     id_marca           VARCHAR(10),
     id_linea           VARCHAR(10),
     id_modelo          VARCHAR(10),
     tipomaquin         VARCHAR(10),
     seriemaq           VARCHAR(20),
     motor              VARCHAR(20),
     chasis             VARCHAR(20),
     asignacion_vigente VARCHAR(30),
     tipounidad         VARCHAR(2),
     orden_trabajo      VARCHAR(10),
     contrato           VARCHAR(20),
     usuario            VARCHAR(20),
     fecha              DATE,
     hora               TIME,
     -- Define si reporta o no a la policia
     reportar           VARCHAR(1),
     --Estado de las transmisiones
     estado_envio       VARCHAR(1),
     ultima_fecha       DATE,
     PRIMARY KEY (id_equipo),
     UNIQUE (id_equipo)
  )

IF Object_id('dbo.unidad', 'U') IS NOT NULL
  DROP TABLE [dbo].unidad

CREATE TABLE [dbo].unidad
  (
     id_unidad         VARCHAR(30),
     serie_dispositivo VARCHAR(30),
     id_marca          VARCHAR(10),
     id_linea          VARCHAR(10),
     imei              VARCHAR(50),
     tarjeta_sim       VARCHAR(50),
     numero_movil      VARCHAR(20),
     opera_movil       VARCHAR(30),
     opera_satel       VARCHAR(30),
     observacion       VARCHAR(50),
     fecunidad         VARCHAR(19),
     usuario           VARCHAR(20),
     estado            VARCHAR(20),
     estado_envio      VARCHAR(1),
     fecha             DATE,
     hora              TIME,
     PRIMARY KEY (id_unidad),
     UNIQUE (id_unidad)
  )

IF Object_id('dbo.asignacion', 'U') IS NOT NULL
  DROP TABLE [dbo].asignacion

CREATE TABLE [dbo].asignacion
  (
     ssas         VARCHAR(30) NOT NULL,
     id_equipo    VARCHAR(20) NOT NULL,
     id_unidad    VARCHAR(30) NOT NULL,
     docinstal    VARCHAR(20) NOT NULL,
     estado_envio VARCHAR(1) NOT NULL,
     usuario      VARCHAR(20) NOT NULL,
     fecha        DATE,
     hora         TIME,
     PRIMARY KEY ( ssas ),
     UNIQUE ( ssas )
  )

IF Object_id('dbo.ubicacion', 'U') IS NOT NULL
  DROP TABLE [dbo].ubicacion

CREATE TABLE [dbo].ubicacion
  (
     id_trama         VARCHAR(20),
     id_unidad        VARCHAR(30),
     tipo_transmision VARCHAR(20),
     longitud         VARCHAR(20),
     latitud          VARCHAR(20),
     velocidad        VARCHAR(20),
     direccion        VARCHAR(20),
     fechagps         DATE,
     evento           VARCHAR(20),
     ignicion         VARCHAR(20),
     pip              VARCHAR(20),
     puerto           VARCHAR(20),
     estado_envio     VARCHAR(1),
     odometro         VARCHAR(20)
     PRIMARY KEY ( id_trama ),
     UNIQUE ( id_trama )
  )

IF Object_id('dbo.lista_correo', 'U') IS NOT NULL
  DROP TABLE [dbo].lista_correo

CREATE TABLE [dbo].lista_correo
  (
     id_lista          INT NOT NULL IDENTITY,
     proceso           VARCHAR(4),
     tipo_notificacion VARCHAR(10),
     email_remitente   VARCHAR(200),
     asunto            VARCHAR(200),
     email_destino     VARCHAR(200),
     email_copia       VARCHAR(200),
     usuariop_mod      VARCHAR(10),
     fecha_mod         DATE,
     PRIMARY KEY ( id_lista ),
     UNIQUE ( id_lista )
  )

IF Object_id('dbo.texto_certificado', 'U') IS NOT NULL
  DROP TABLE [dbo].texto_certificado

CREATE TABLE [dbo].texto_certificado
  (
     secuencia         INT,
     texto_certificado VARCHAR(1000),
     usuario_txt       VARCHAR(20),
     fecha_txt         DATE,
     hora_txt          TIME,
     PRIMARY KEY (secuencia),
     UNIQUE (secuencia)
  )

-- ADD CONSTRAINTS
ALTER TABLE [dbo].equipo
  ADD CONSTRAINT fk_equipo_marca FOREIGN KEY (id_marca) REFERENCES marca (
  id_marca) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE [dbo].equipo
  ADD CONSTRAINT fk_equipo_linea FOREIGN KEY (id_linea) REFERENCES linea (
  id_linea) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE [dbo].equipo
  ADD CONSTRAINT fk_equipo_modelo FOREIGN KEY (id_modelo) REFERENCES modelo (
  id_modelo) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE [dbo].equipo
  ADD CONSTRAINT fk_equipo_asignacion FOREIGN KEY (asignacion_vigente)
  REFERENCES asignacion ( ssas);

ALTER TABLE [dbo].unidad
  ADD CONSTRAINT fk_unidad_marca FOREIGN KEY (id_marca) REFERENCES marca (
  id_marca) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE [dbo].unidad
  ADD CONSTRAINT fk_unidad_linea FOREIGN KEY (id_linea) REFERENCES linea (
  id_linea) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE [dbo].asignacion
  ADD CONSTRAINT fk_asignacion_equipo FOREIGN KEY (id_equipo) REFERENCES equipo
  (id_equipo) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE [dbo].asignacion
  ADD CONSTRAINT fk_asignacion_unidad FOREIGN KEY (id_unidad) REFERENCES unidad
  (id_unidad);

ALTER TABLE [dbo].ubicacion
  ADD CONSTRAINT fk_ubicacion_unidad FOREIGN KEY (id_unidad) REFERENCES unidad (
  id_unidad) ON DELETE CASCADE ON UPDATE CASCADE;