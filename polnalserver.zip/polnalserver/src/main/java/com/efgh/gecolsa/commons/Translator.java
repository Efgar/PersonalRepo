package com.efgh.gecolsa.commons;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import java.util.Optional;

@Configuration
@PropertySource("classpath:language_es.properties")
public class Translator {

    @Autowired
    private Environment environment;

    public String translate(String propertyKey) {
        return Optional.of(environment.getProperty(propertyKey)).orElse(propertyKey);
    }

}
