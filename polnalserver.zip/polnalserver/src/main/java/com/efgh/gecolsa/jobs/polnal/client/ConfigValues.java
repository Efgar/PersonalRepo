package com.efgh.gecolsa.jobs.polnal.client;

class ConfigValues {

    static final String NAMESPACE_URL = "http://policia.gov.co/webservice";
    static final String SERVICE_NAME = "Service1";
    static final String SERVICE_PORT = "Service1Soap";
}
