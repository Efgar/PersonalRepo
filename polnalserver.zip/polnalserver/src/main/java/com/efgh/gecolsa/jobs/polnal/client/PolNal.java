package com.efgh.gecolsa.jobs.polnal.client;

import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;
import java.net.URL;

public interface PolNal extends Service {

    PolNalSoap getService1Soap() throws ServiceException;

    PolNalSoap getService1Soap(URL portAddress) throws ServiceException;
}
