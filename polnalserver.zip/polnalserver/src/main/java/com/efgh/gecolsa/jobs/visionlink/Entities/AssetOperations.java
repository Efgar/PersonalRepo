package com.efgh.gecolsa.jobs.visionlink.Entities;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@Data
@XmlRootElement(name = "AssetOperations")
@XmlAccessorType(XmlAccessType.FIELD)
public class AssetOperations extends Navigable {

    @XmlElement(name = "Nav")
    Navigation nav;

    @XmlElement(name = "IsLastPage")
    boolean isLastPage;

    @XmlElement(name = "AssetOperation")
    List<AssetOperation> assetOperations;
}
