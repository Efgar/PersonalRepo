package com.efgh.gecolsa.jobs.visionlink.Entities;

import lombok.Data;

@Data
public abstract class Navigable {
    public abstract Navigation getNav();

    public abstract boolean isLastPage();

    public String getNextPageLink() {
        for (NavigationLink navigationLink : getNav().link) {
            if (navigationLink.rel.equalsIgnoreCase("next")) {
                return navigationLink.href;
            }
        }
        return null;
    }
}
