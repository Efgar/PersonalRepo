package com.efgh.gecolsa.jobs.visionlink;

import com.efgh.gecolsa.commons.MailHelper;
import com.efgh.gecolsa.commons.Translator;
import com.efgh.gecolsa.jobs.visionlink.Entities.Asset;
import com.efgh.gecolsa.jobs.visionlink.Entities.AssetOperationDateInfo;
import com.efgh.gecolsa.jobs.visionlink.Entities.AssetOperations;
import com.efgh.gecolsa.model.jpa.ObjectValidator;
import com.efgh.gecolsa.model.jpa.entity.Ubicacion;
import com.efgh.gecolsa.model.jpa.entity.UnidadRastreo;
import com.efgh.gecolsa.model.jpa.repository.AsignacionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Collection;

import static com.efgh.gecolsa.jobs.visionlink.Entities.AssetOperationDateInfo.ISO8601_FORMAT;

@Component
public class VisionLinkJob {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${gecolsa.policiagps.visionlink.assetoperations.url}")
    private String assetOperationsBaseURL;
    @Value("${gecolsa.policiagps.visionlink.user}")
    private String visionLinkUser;
    @Value("${gecolsa.policiagps.visionlink.pass}")
    private String visionLinkPass;

    @Autowired
    private AsignacionRepository asignacionRepo;

    @Autowired
    private Translator translator;

    @Autowired
    private ObjectValidator objectValidator;

    @Autowired
    private MailHelper mailHelper;

    @Scheduled(cron = "${gecolsa.policiagps.visionlink.cron}")
    public void getVisionLinkData() {
        processAssetsOperationData();
    }

    private void processAssetsOperationData() {
        logger.info(translator.translate("efgh.polnal.logger.separator"));
        logger.info(translator.translate("efgh.polnal.job.visionlink.send.start"));
        logger.info(translator.translate("efgh.polnal.logger.separator"));
        LocalDateTime pastHourDate = LocalDateTime.now(ZoneId.of("UTC")).minus(60, ChronoUnit.MINUTES);
        String assetOperationsURL = assetOperationsBaseURL.concat("?LastBookmarkUTC=").concat(pastHourDate.format(ISO8601_FORMAT));
        NavigableHelper<AssetOperations> assetsHelper = new NavigableHelper(AssetOperations.class, assetOperationsURL, visionLinkUser, visionLinkPass);
        assetsHelper.getPages().stream().map(AssetOperations::getAssetOperations).flatMap(Collection::stream).forEach(assetOperation -> {
            Asset asset = assetOperation.getAsset();
            UnidadRastreo unidadProceso = asignacionRepo.findActiveUnitForEquipo(asset.getAssetID());
            if (unidadProceso == null) {
                logger.error(String.format("El equipo con ID [%s] no tiene una unidad registrada en el sistema.", asset.getAssetID()));
                mailHelper.sendErrorMail(String.format("El equipo con ID [%s] no tiene una unidad registrada en el sistema.", asset.getAssetID()), null);
            } else {
                assetOperation.getAssetOperationDetails().getAssetOperationDates().forEach(assetOperationDate -> {
                    AssetOperationDateInfo operationInfo = assetOperationDate.getAssetOperationDateInfos().stream().sorted().findFirst().orElse(null);
                    if (operationInfo != null) {
                        Ubicacion newUbicacion = new Ubicacion();
                        newUbicacion.setId_trama(String.valueOf(operationInfo.hashCode()));
                        newUbicacion.setTipo_transmision("VISIONLINK");
                        newUbicacion.setLongitud(String.valueOf(operationInfo.getEndLocation().getLongitude()));
                        newUbicacion.setLatitud(String.valueOf(operationInfo.getEndLocation().getLatitude()));
                        newUbicacion.setFechaGPS(operationInfo.getLocalDateToReport());
                        newUbicacion.setIgnicion("0");
                        newUbicacion.setPip("192.168.0.1");
                        newUbicacion.setPuerto("8080");
                        newUbicacion.setEvento(operationInfo.getWorkDefinition());
                        newUbicacion.setEstado(operationInfo.getWorkingState());
                        newUbicacion.setVelocidad(String.valueOf(operationInfo.getCalculatedSpeed()));
                        newUbicacion.setUnidad(asignacionRepo.findActiveUnitForEquipo(asset.getAssetID()));
                        //TODO Saving

                        try {
                            objectValidator.validate("Ubicacion", newUbicacion.getId_trama(), newUbicacion);
                        } catch (IOException e) {
                            logger.error("No se puede guardar el registro recibido de vision link.", e);
                            mailHelper.sendErrorMail("No se puede guardar el registro recibido de vision link.", e);
                        }
                    }
                });
            }
        });

        logger.info(translator.translate("efgh.polnal.logger.separator"));
        logger.info(translator.translate("efgh.polnal.job.visionlink.send.finish"));
        logger.info(translator.translate("efgh.polnal.logger.separator"));
    }
}
