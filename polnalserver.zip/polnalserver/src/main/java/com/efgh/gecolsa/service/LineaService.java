package com.efgh.gecolsa.service;

import com.efgh.gecolsa.model.jpa.ObjectValidator;
import com.efgh.gecolsa.model.jpa.entity.Linea;
import com.efgh.gecolsa.model.jpa.repository.LineaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class LineaService {

    private final ObjectValidator objectValidator;

    private final LineaRepository lineaRepo;

    @Autowired
    public LineaService(ObjectValidator objectValidator, LineaRepository lineaRepository) {
        this.objectValidator = objectValidator;
        this.lineaRepo = lineaRepository;
    }

    public Linea insertarLinea(Linea linea) throws IOException {
        objectValidator.validate("Linea", String.valueOf(linea.getId_linea()), linea);
        if (linea.getId_linea() != null) {
            Assert.isTrue(!lineaRepo.existsById(linea.getId_linea()), "Ya existe un objeto con el ID especificado");
        }
        lineaRepo.save(linea);
        return linea;
    }

    public List<Linea> getLineas(int page, String code) {
        if(!StringUtils.isEmpty(code)){
            return lineaRepo.findByCod__linea__cat(code, PageRequest.of(page,20)).getContent();
        }
        return lineaRepo.findAll(PageRequest.of(page, 20)).getContent();
    }

    public Linea getLinea(Long idLinea) {
        return lineaRepo.findById(idLinea).orElseThrow(() -> new NoSuchElementException("No existe Linea con el ID_LINEA especificado"));
    }
}
