package com.efgh.gecolsa.service;

import com.efgh.gecolsa.model.jpa.ObjectValidator;
import com.efgh.gecolsa.model.jpa.entity.Ubicacion;
import com.efgh.gecolsa.model.jpa.repository.UbicacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

@Service
public class MachineLocationService {

    private final ObjectValidator objectValidator;

    private final UbicacionRepository ubicacionRepo;

    @Autowired
    public MachineLocationService(ObjectValidator objectValidator, UbicacionRepository ubicacionRepo) {
        this.objectValidator = objectValidator;
        this.ubicacionRepo = ubicacionRepo;
    }

    public void insertMachineLocation(Ubicacion ubicacion) throws IOException {
        objectValidator.validate("Ubicacion", ubicacion.getId_trama(), ubicacion);
        ubicacionRepo.save(ubicacion);
    }

    public List<Ubicacion> getMachineLocations(int locationsAmount) {
        return ubicacionRepo.findFirstGiven(locationsAmount);
    }
}
