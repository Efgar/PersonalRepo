package com.efgh.gecolsa.commons;

import com.efgh.gecolsa.model.jpa.entity.ListaCorreo;
import com.efgh.gecolsa.model.jpa.repository.ListaCorreoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.internet.MimeMessage;
import java.util.stream.Collectors;

@Service
public class MailHelper {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${general.appname}")
    private String appName;

    @Autowired
    private JavaMailSender sender;

    @Autowired
    Translator translator;

    @Autowired
    private ListaCorreoRepository mailingListRepo;

    @Value("${gecolsa.policiagps.general.generalerrormail}")
    private String errorMailDestinatary;

    public void sendMail(String mailBody, String destino) {
        sendMail(mailBody, null, false, destino);
    }

    public void sendErrorMail(String mailBody, Exception exc) {
        sendMail(mailBody, exc, false, getErrorMailDestinataries());
    }

    public void sendMail(String mailBody, Exception exc, boolean isInfo, String destinationAddresses) {
        try {
            MimeMessage message = sender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setFrom(translator.translate("efgh.mail.from")+ appName);
            helper.setBcc(destinationAddresses);
            helper.setSubject(getSubject(isInfo));
            helper.setText(getMailBody(mailBody, exc));

            sender.send(message);
        } catch (Exception e) {
            logger.error(translator.translate("efgh.mail.error.sent"), e);
        }
    }

    private String getSubject(boolean isInfo){
        StringBuilder mailSubject = new StringBuilder();
        if(!isInfo){
            mailSubject.append (translator.translate("efgh.mail.subject.error"));
        }
        mailSubject.append(String.format (translator.translate("efgh.mail.subject.alert"), appName));
        return mailSubject.toString();
    }

    private String getMailBody(String mailBody, Exception exc) {
        StringBuilder mailText = new StringBuilder();

        mailText.append(translator.translate("efgh.mail.body.greeting"));
        mailText.append(System.lineSeparator());
        mailText.append(String.format(translator.translate("efgh.mail.body.alert"), appName));
        mailText.append(System.lineSeparator());
        mailText.append(String.format(translator.translate("efgh.mail.body.event"), mailBody));
        mailText.append(System.lineSeparator());
        mailText.append(String.format(translator.translate("efgh.mail.body.detail"), getExceptionMessage(exc)));

        return mailText.toString();
    }

    private static String getExceptionMessage(Exception e) {
        if (e == null) {
            return "N/A";
        }
        StringBuilder stack = new StringBuilder();
        stack.append("--------------------------\n");
        stack.append(String.format("EXCEPCION ASOCIADA:%s", e.toString()));
        StackTraceElement[] aux = e.getStackTrace();
        for (StackTraceElement aux1 : aux) {
            stack.append(aux1.toString()).append("\n");
        }
        stack.append("--------------------------");
        return stack.toString();
    }

    private String getErrorMailDestinataries() {
        final String processIdentifier = "";
        return String.join(",", mailingListRepo.findByProceso(processIdentifier).stream().map(ListaCorreo::getEmail_destino).collect(Collectors.joining(",")), errorMailDestinatary);
    }
}
