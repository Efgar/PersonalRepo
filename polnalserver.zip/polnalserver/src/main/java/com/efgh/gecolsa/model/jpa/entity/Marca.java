package com.efgh.gecolsa.model.jpa.entity;

import com.efgh.gecolsa.model.jpa.entity.validation.Numeric;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Data
@Entity(name = "marca")
public class Marca {

    @Id
    @GeneratedValue
    @Column(name="id_marca")
    Long id_marca;

    @Numeric
    @Column(name="cod_marca_cat")
    String cod_marca_cat = "0";

    @NotNull
    @Column(name="desc_marca")
    String desc_marca = "";
}
