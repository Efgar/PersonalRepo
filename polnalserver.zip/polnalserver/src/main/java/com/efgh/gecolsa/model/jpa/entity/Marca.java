package com.efgh.gecolsa.model.jpa.entity;

import com.efgh.gecolsa.model.jpa.entity.validation.Numeric;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity(name = "marca")
public class Marca {

    @Id
    @Column(name="id_marca")
    String id_marca;

    @Numeric
    @Column(name="cod_marca_cat")
    String cod_marca_cat = "0";

    @Column(name="desc_marca")
    String desc_marca;
}
