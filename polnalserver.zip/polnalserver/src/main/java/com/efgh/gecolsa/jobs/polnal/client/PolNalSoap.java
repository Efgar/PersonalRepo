package com.efgh.gecolsa.jobs.polnal.client;

import java.io.IOException;
import java.rmi.RemoteException;

public interface PolNalSoap extends java.rmi.Remote {
    PolNalResponses.Validation valIngreso(String PUSUARIOPROV, String PCLAVEPROV, String PNUMEROVALIDO) throws IOException;

    PolNalResponses.EntitiesInsertion mqaConsDispAVL(String PUSUARIO, String PTOKEN, String PMQASERIE, String PMQAMOTOR, String PMQACHASIS, String PDISIMEI, String PTIDPROV, String PIDEPROV) throws RemoteException;

    PolNalResponses.EntitiesInsertion insertarUbicacion(String PUSUARIO, String PTOKEN, String PIDTRAMA, String PIDUNIDAD, String PTIPTRANSM, String PLONGITUD, String PLATITUD, String PVELOCIDAD, String PDIRECCION, String PFECHAGPS, String PEVENTO, String PIGNICION, String PIP, String PPUERTO, String PSTATUS, String PODOMETRO) throws RemoteException;

    PolNalResponses.EntitiesInsertion insertarUnidadesdeRastreo(String PUSUARIO, String PTOKEN, String PIDUNIDAD, String PCODIMARCA, String PCODILINEA, String PIMEI, String PTARJETA_SIM, String PNRO_MOVIL, String POPERADORMOVIL, String POPERADORSATELITAL, String POBSERVACION, String PSERIE_DISPOSITIVO) throws RemoteException;

    PolNalResponses.EntitiesInsertion insertarMaquinas(String PUSUARIO, String PTOKEN, String PIDRUNT, String PSERIE, String PCODIMARCA, String PCODILINEA, String PMODELO, String PTIPOMAQUINA, String PIDUNIDADVIGENTE, String PMOTOR, String PCHASIS, String PTIPOUNIDADMAQUINA) throws RemoteException;

    PolNalResponses.RelationsInsertion relacionMaquinaUnidad(String PUSUARIO, String PTOKEN, String PMAQUINAIDRUNT, String PUNIDRASTIDUNIDAD, String PDOCUMENTOINSTALACIONA) throws RemoteException;
}
