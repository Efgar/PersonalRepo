package com.efgh.gecolsa.controller.polnal;

import com.efgh.gecolsa.model.jpa.entity.UnidadRastreo;
import com.efgh.gecolsa.service.UnidadRastreoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/v1.0/unidad")
public class UnidadRastreoController {

    private final UnidadRastreoService unidadRastreoService;

    @Autowired
    public UnidadRastreoController(UnidadRastreoService unidadRastreoService) {
        this.unidadRastreoService = unidadRastreoService;
    }

    @PostMapping
    public UnidadRastreo insertUnidadRastreo(@RequestBody UnidadRastreo unidad) throws IOException {
        return unidadRastreoService.insertUnidadRastreo(unidad);
    }

    @GetMapping
    public List<UnidadRastreo> getUnidadesRastreo(@RequestParam(defaultValue = "0") int page) {
        return unidadRastreoService.getUnidadesRastreo(page);
    }

    @GetMapping("/{idUnidad}")
    public UnidadRastreo getUnidadRastreo(@PathVariable String idUnidad) {
        return unidadRastreoService.getUnidadRastreo(idUnidad);
    }
}
