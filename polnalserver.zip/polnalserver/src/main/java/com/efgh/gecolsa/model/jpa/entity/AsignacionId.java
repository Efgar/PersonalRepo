package com.efgh.gecolsa.model.jpa.entity;


import lombok.Data;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.io.Serializable;

@Embeddable
@Data
public class AsignacionId implements Serializable {

    @ManyToOne
    @JoinColumn(name="id_unidad")
    UnidadRastreo unidad;

    @ManyToOne
    @JoinColumn(name="id_equipo")
    Equipo equipo;

}
