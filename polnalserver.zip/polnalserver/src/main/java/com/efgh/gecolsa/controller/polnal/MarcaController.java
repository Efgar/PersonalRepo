package com.efgh.gecolsa.controller.polnal;

import com.efgh.gecolsa.model.jpa.entity.Marca;
import com.efgh.gecolsa.service.MarcaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/v1.0/marca")
public class MarcaController {

    private final MarcaService marcaService;

    @Autowired
    public MarcaController(MarcaService marcaService) {
        this.marcaService = marcaService;
    }

    @PostMapping
    public Marca insertarMarca(@RequestBody Marca marca) throws IOException {
        return marcaService.insertarMarca(marca);
    }

    @GetMapping
    public List<Marca> getMarcas(@RequestParam(defaultValue = "0") int page, @RequestParam(required = false) String code) {
        return marcaService.getMarcas(page, code);
    }

    @GetMapping("/{idMarca}")
    public Marca getMArca(@PathVariable Long idMarca) {
        return marcaService.getMarca(idMarca);
    }
}
