package com.efgh.gecolsa.jobs.visionlink.Entities;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;


@Data
@EqualsAndHashCode(callSuper = true)
@XmlRootElement(name = "Assets")
@XmlAccessorType(XmlAccessType.FIELD)
public class Assets extends Navigable {

    @XmlElement(name = "Nav")
    Navigation nav;

    @XmlElement(name = "Asset")
    List<Asset> asset;

    @XmlElement(name = "IsLastPage")
    boolean isLastPage;
}
