package com.efgh.gecolsa.model.jpa.entity;

public class Enums {
    public enum TransmissionType {
        CL,
        ST,
        DL
    }

    public enum Direction {
        N,
		NE,
		E,
		SE,
		S,
		SO,
		O,
		NO;
    }

    public enum SentStatus {
        N,
        NE,
        E,
        SE,
        S,
        SO,
        O,
        NO;
    }
}
