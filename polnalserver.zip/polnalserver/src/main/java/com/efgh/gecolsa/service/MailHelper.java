package com.efgh.gecolsa.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.internet.MimeMessage;

@Service
public class MailHelper {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${general.appname}")
    private String appName;

    @Autowired
    private JavaMailSender sender;

    public void sendMail(String mailBody, String destino) {
        sendMail(mailBody, null, false, destino);
    }

    public void sendMail(String mailBody, Exception exc, boolean isInfo, String destinationAddresses) {
        try {
            MimeMessage message = sender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setFrom("Reporte-" + appName);
            helper.setBcc(destinationAddresses);
            helper.setSubject(getSubject(isInfo));
            helper.setText(getMailBody(mailBody, exc));

            sender.send(message);
        } catch (Exception e) {
            logger.error("ERROR ENVIANDO NOTIFICACION VIA EMAIL.", e);
        }
    }

    private String getSubject(boolean isInfo){
        StringBuilder mailSubject = new StringBuilder();
        if(!isInfo){
            mailSubject.append("[ERROR]");
        }
        mailSubject.append(String.format("Correo de alerta: %s", appName));
        return mailSubject.toString();
    }

    private String getMailBody(String mailBody, Exception exc) {
        StringBuilder mailText = new StringBuilder();

        mailText.append("Buen dia,\n\n");
        mailText.append(String.format("Este es un correo de alerta de la aplicacion %s.\n\n", appName));
        mailText.append(String.format("El siguiente evento ha tenido lugar dentro del sistema: %s\n\n", mailBody));
        mailText.append(String.format("Detalle de la excepcion:\n%s\n", getExceptionMessage(exc)));

        return mailText.toString();
    }

    private static String getExceptionMessage(Exception e) {
        if (e == null) {
            return "N/A";
        }
        StringBuilder stack = new StringBuilder();
        stack.append("--------------------------\n");
        stack.append(String.format("EXCEPCION ASOCIADA:\n%s\n", e.toString()));
        StackTraceElement[] aux = e.getStackTrace();
        for (StackTraceElement aux1 : aux) {
            stack.append(aux1.toString()).append("\n");
        }
        stack.append("--------------------------");
        return stack.toString();
    }
}
