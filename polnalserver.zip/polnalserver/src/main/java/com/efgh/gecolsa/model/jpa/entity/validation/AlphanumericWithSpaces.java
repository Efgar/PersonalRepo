package com.efgh.gecolsa.model.jpa.entity.validation;

import javax.validation.Constraint;
import javax.validation.OverridesAttribute;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.Integer.MAX_VALUE;
import static java.lang.annotation.ElementType.*;

@Pattern(regexp = "^[a-zA-Z0-9 ]*$")
@Size
@NotNull
@ReportAsSingleViolation
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target( { FIELD, METHOD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Constraint(validatedBy={})
public @interface AlphanumericWithSpaces {
    String message() default "debe ser alfanumérico con espacios y el tamaño debe estar entre {minLength} y {maxLength}";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};

    @OverridesAttribute(constraint=Size.class, name="min")
    int minLength() default 0;

    @OverridesAttribute(constraint=Size.class, name="max")
    int maxLength() default MAX_VALUE;
}