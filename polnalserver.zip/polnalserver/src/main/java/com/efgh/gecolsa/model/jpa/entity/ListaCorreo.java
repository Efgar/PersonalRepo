package com.efgh.gecolsa.model.jpa.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDateTime;

@Data
@Entity(name = "lista_correo")
public class ListaCorreo {

    @Id
    @Column(name = "id_notificacion")
    Long id_notificacion;

    @Column(name = "proceso")
    String proceso;

    @Column(name = "tipo_notificacion")
    String tipo_notificacion;

    @Column(name = "email_remitente")
    String email_remitente;

    @Column(name = "asunto")
    String asunto;

    @Column(name = "email_destino")
    String email_destino;

    @Column(name = "email_copia")
    String email_copia;

    @Column(name = "usuariop_mod")
    String usuariop_mod;

    @Column(name = "fecha_mod")
    LocalDateTime fecha_mod;

}
