package com.efgh.gecolsa.model.jpa.repository;

import com.efgh.gecolsa.model.jpa.entity.Ubicacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UbicacionRepository extends JpaRepository<Ubicacion, Long> {

    @Query(nativeQuery = true, value = "SELECT TOP :amount * FROM Ubicacion u ORDER BY u.fechaGPS DESC")
    List<Ubicacion> findFirstGiven(int amount);
}
