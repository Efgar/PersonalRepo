package com.efgh.gecolsa.model.jpa.repository;

import com.efgh.gecolsa.model.jpa.entity.Enums.SentStatus;
import com.efgh.gecolsa.model.jpa.entity.Ubicacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UbicacionRepository extends JpaRepository<Ubicacion, String> {
    List<Ubicacion> findByEstadoEnvio(SentStatus estadoEnvio);
}
