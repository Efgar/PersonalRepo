package com.efgh.gecolsa.jobs.polnal.client;

import org.apache.axis.client.Service;
import org.apache.axis.client.Stub;

import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;
import java.net.URL;
import java.rmi.Remote;
import java.util.HashSet;
import java.util.Iterator;

import static com.efgh.gecolsa.jobs.polnal.client.ConfigValues.*;

public class PolNalLocator extends Service implements PolNal {

    private HashSet<QName> ports = null;

    // Use to get a proxy class for PolNalSoap
    private String Service1Soap_address = "https://logmqa.policia.gov.co/Service1.asmx";

    private String getService1SoapWSDDServiceName() {
        return SERVICE_PORT;
    }

    public PolNalSoap getService1Soap() throws ServiceException {
        URL endpoint;
        try {
            endpoint = new URL(Service1Soap_address);
        } catch (java.net.MalformedURLException e) {
            throw new ServiceException(e);
        }
        return getService1Soap(endpoint);
    }

    public PolNalSoap getService1Soap(URL portAddress) {
        PolNalStub _stub = new PolNalStub(portAddress, this);
        _stub.setPortName(getService1SoapWSDDServiceName());
        return _stub;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public Remote getPort(Class serviceEndpointInterface) throws ServiceException {
        try {
            if (PolNalSoap.class.isAssignableFrom(serviceEndpointInterface)) {
                PolNalStub _stub = new PolNalStub(new URL(Service1Soap_address), this);
                _stub.setPortName(getService1SoapWSDDServiceName());
                return _stub;
            }
        } catch (Throwable t) {
            throw new ServiceException(t);
        }
        throw new ServiceException("There is no stub implementation for the interface:  " + serviceEndpointInterface.getName());
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public Remote getPort(QName portName, Class serviceEndpointInterface) throws ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        String inputPortName = portName.getLocalPart();
        if (SERVICE_PORT.equals(inputPortName)) {
            return getService1Soap();
        } else {
            Remote _stub = getPort(serviceEndpointInterface);
            ((Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public QName getServiceName() {
        return new QName(NAMESPACE_URL, SERVICE_NAME);
    }

    public Iterator getPorts() {
        if (ports == null) {
            ports = new HashSet<>();
            ports.add(new QName(NAMESPACE_URL, SERVICE_PORT));
        }
        return ports.iterator();
    }

}
