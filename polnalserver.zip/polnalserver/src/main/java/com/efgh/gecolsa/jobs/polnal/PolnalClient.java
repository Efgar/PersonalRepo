package com.efgh.gecolsa.jobs.polnal;

import com.efgh.gecolsa.jobs.polnal.client.PolNalProxy;
import com.efgh.gecolsa.jobs.polnal.client.PolNalResponses;
import com.efgh.gecolsa.jobs.polnal.client.PolNalResponses.PolnalResponse;
import com.efgh.gecolsa.model.jpa.ObjectValidator;
import com.efgh.gecolsa.model.jpa.entity.*;
import com.efgh.gecolsa.model.jpa.repository.ListaCorreoRepository;
import com.efgh.gecolsa.service.MailHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.stream.Collectors;

@Component
class PolnalClient {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private PolNalProxy proxy = new PolNalProxy(5);

    private final MailHelper mailHelper;

    private final ListaCorreoRepository mailingListRepo;

    private final ObjectValidator objectValidator;

    @Value("${gecolsa.policiagps.general.generalerrormail}")
    private String errorMailDestinatary;

    @Autowired
    public PolnalClient(MailHelper mailHelper, ListaCorreoRepository mailingListRepo, ObjectValidator objectValidator) {
        this.mailHelper = mailHelper;
        this.mailingListRepo = mailingListRepo;
        this.objectValidator = objectValidator;
    }

    /**
     * Returns the authentication token
     *
     * @param usuario      user to be used on the WS authentication
     * @param clave        password to be used on the WS authentication
     * @param numeroValido unique id of the company making the call
     * @return token number if the call was ok, 0 if the WS response was negative or null if there was a comunication issue
     * @throws IOException if there is any error in the service consumption
     */
    String getToken(String usuario, String clave, String numeroValido) throws IOException {
        try {
            PolNalResponses.Validation validationResponse = proxy.valIngreso(usuario, clave, numeroValido);
            if (!validationResponse.isOk()) {
                throw new IOException(validationResponse.code + " :: " + validationResponse);
            }
            return validationResponse.token;
        } catch (Exception e) {
            handleServiceCallException(e, "valIngreso", usuario, "N/A", String.join("::", usuario, clave, numeroValido));
            throw new IOException("Error ejecutando el llamado al servicio de autenticacion (valIngreso)", e);
        }
    }

    boolean insertMachine(String usuario, String token, Equipo equipo) {
        try {
            String entityName = "Equipo";
            objectValidator.validate(entityName, equipo.getId_equipo(), equipo);
            PolnalResponse serviceCall = proxy.insertarMaquinas(usuario, token, equipo.getId_runt(), equipo.getSeriemaq(),
                    equipo.getMarca().getCod_marca_cat(), equipo.getLinea().getCod_linea_cat(), equipo.getModelo().getCod_modelo(), equipo.getTipomaquin(),
                    String.valueOf(equipo.getTipounidad()), equipo.getMotor(), equipo.getChasis(),
                    equipo.getId_unidad_vigente());

            handleServiceCallResponse(serviceCall, entityName, equipo.toString());
        } catch (Exception e) {
            handleServiceCallException(e, "insertarMaquina", usuario, token, equipo.toString());
        }
        return true;
    }

    boolean insertTrackingUnit(String usuario, String token, UnidadRastreo unidad) {
        try {
            String entityName = "Unidad de rastreo";
            objectValidator.validate(entityName, unidad.getId_unidad(), unidad);
            PolnalResponse serviceCall = proxy.insertarUnidadesdeRastreo(usuario, token, unidad.getId_unidad(),
                    unidad.getMarca().getCod_marca_cat(), unidad.getLinea().getCod_linea_cat(), unidad.getImei(), unidad.getTarjeta_sim(),
                    unidad.getNumero_movil(), unidad.getOpera_movil(), unidad.getOpera_satel(),
                    unidad.getObservacion(), unidad.getSerie_dispositivo());

            handleServiceCallResponse(serviceCall, entityName, unidad.toString());
        } catch (Exception e) {
            handleServiceCallException(e, "insertarUnidadesdeRastreo", usuario, token, unidad.toString());
        }
        return true;
    }

    boolean insertTrackingUnitMachineRelation(String usuario, String token, Asignacion asignation) {
        try {
            String entityName = "Relacion";
            objectValidator.validate(entityName, String.valueOf(asignation.getId()), asignation);
            PolnalResponse serviceCall = proxy.relacionMaquinaUnidad(usuario, token, asignation.getId().getEquipo().getId_runt(),
                    asignation.getId().getUnidad().getId_unidad(), asignation.getDocinstal());

            handleServiceCallResponse(serviceCall, entityName, asignation.toString());
        } catch (Exception e) {
            handleServiceCallException(e, "relacionMaquinaUnidad", usuario, token, asignation.toString());
        }
        return true;
    }

    boolean insertMachineLocation(String usuario, String token, Ubicacion ubicacion) {
        try {
            String entityName = "Ubicacion";
            objectValidator.validate(entityName, ubicacion.getId_trama(), ubicacion);
            PolnalResponse serviceCall = proxy.insertarUbicacion(usuario, token, ubicacion.getId_trama(), ubicacion.getUnidad().getId_unidad(),
                    ubicacion.getTipo_transmision(), ubicacion.getLongitud(), ubicacion.getLatitud(),
                    ubicacion.getVelocidad(), String.valueOf(ubicacion.getDireccion()), ubicacion.getFechaGPS().toString(), ubicacion.getEvento(),
                    ubicacion.getIgnicion(), ubicacion.getPip(), ubicacion.getPuerto(), String.valueOf(ubicacion.getStatus()),
                    ubicacion.getOdometro());
            handleServiceCallResponse(serviceCall, entityName, ubicacion.toString());
        } catch (Exception e) {
            handleServiceCallException(e, "insertarUbicacion", usuario, token, ubicacion.toString());
        }
        return true;
    }

    private void handleServiceCallResponse(PolnalResponse serviceCallResponse, String entityName, String entityDetails) throws IOException {
        if (serviceCallResponse.isDuplicated()) {
            logger.warn("No se puede insertar " + entityName + ", registro duplicado.\r\n" + serviceCallResponse + "\r\n" + entityDetails);
        } else if (!serviceCallResponse.isOk()) {
            logger.error("Error insertando " + entityName + ", respuesta de la invocacion: " + serviceCallResponse);
            throw new IOException(serviceCallResponse.getCode() + " :: " + serviceCallResponse.getMessage());
        }
    }

    private void handleServiceCallException(Exception e, String serviceName, String user, String token, String objectRepresentation) {
        String mainErrorMessage = String.format("Error ejecutando el llamado al servicio [%s].", serviceName);

        logger.error(mainErrorMessage, e);
        logCallParameters(serviceName, user, token, objectRepresentation);

        mailHelper.sendMail(mainErrorMessage, e, false, getErrorMailDestinataries());
    }

    private String getErrorMailDestinataries() {
        final String processIdentifier = "";
        return String.join(",", mailingListRepo.findByProceso(processIdentifier).stream().map(ListaCorreo::getEmail_destino).collect(Collectors.joining(",")), errorMailDestinatary);
    }

    private void logCallParameters(String endpoint, String... params) {
        StringBuilder parameterList = new StringBuilder();
        for (String param : params) {
            parameterList.append("\r\n\t->\t'").append(param).append("'");
        }
        logger.info("*******************************************");
        logger.info("*** DETALLES DE INVOCACION DEL SERVICIO ***");
        logger.info("Endpoint ejecutado: " + endpoint);
        logger.info("Parametros enviados: " + parameterList);
        logger.info("*******************************************");
    }

}
