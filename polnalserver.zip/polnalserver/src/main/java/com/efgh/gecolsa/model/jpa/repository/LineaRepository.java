package com.efgh.gecolsa.model.jpa.repository;

import com.efgh.gecolsa.model.jpa.entity.Linea;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LineaRepository extends JpaRepository<Linea, Long> {
    Page<Linea> findByCod__linea__cat(String cond_linea_cat, Pageable pageable);
}
