package com.efgh.gecolsa.model.jpa.entity;


import com.efgh.gecolsa.model.jpa.entity.Enums.SentStatus;
import com.efgh.gecolsa.model.jpa.entity.validation.Alphanumeric;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@Entity
@Table(name = "asignacion")
public class Asignacion {

    @NotNull
    @Id
    @Column(name = "saas")
    String ssas;

    @Alphanumeric(maxLength = 100)
    @Column(name = "docinstal")
    String docinstal = "NO APLICA";

    @NotNull
    @Column(name = "estado_envio")
    SentStatus estadoEnvio = Enums.SentStatus.P;

    @Alphanumeric(maxLength = 20)
    @Column(name = "usuario")
    String usuario;

    @Column(name = "fecha")
    LocalDateTime fecha;

    @Column(name = "hora")
    LocalTime hora;

    @ManyToOne
    @JoinColumn(name = "id_unidad")
    UnidadRastreo unidad;

    @ManyToOne
    @JoinColumn(name = "id_equipo")
    Equipo equipo;
}
