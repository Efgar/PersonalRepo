package com.efgh.gecolsa.model.jpa.entity;


import com.efgh.gecolsa.model.jpa.entity.Enums.SentStatus;
import com.efgh.gecolsa.model.jpa.entity.validation.Alphanumeric;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@Entity
@Table(name = "asignacion")
public class Asignacion {

    @Valid
    @Id
    AsignacionId id;

    @Alphanumeric(maxLength = 100)
    @Column(name = "docinstal")
    String docinstal = "NO APLICA";

    @Alphanumeric(maxLength = 1)
    @Column(name = "estadouni")
    SentStatus estadouni;

    @Alphanumeric(maxLength = 20)
    @Column(name = "usuario")
    String usuario;

    @Column(name = "fecha")
    LocalDateTime fecha;

    @Column(name = "hora")
    LocalTime hora;
}
