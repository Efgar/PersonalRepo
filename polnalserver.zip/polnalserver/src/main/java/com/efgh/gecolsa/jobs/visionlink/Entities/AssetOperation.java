package com.efgh.gecolsa.jobs.visionlink.Entities;


import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Data
@XmlRootElement(name = "AssetOperation")
@XmlAccessorType(XmlAccessType.FIELD)
public class AssetOperation {

    @XmlElement(name = "Asset")
    Asset asset;

    @XmlElement(name = "AssetOperationDetails")
    AssetOperationDetails assetOperationDetails;
}
