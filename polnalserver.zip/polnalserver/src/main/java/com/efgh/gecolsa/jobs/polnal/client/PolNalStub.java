package com.efgh.gecolsa.jobs.polnal.client;

import org.apache.axis.AxisFault;
import org.apache.axis.NoEndPointException;
import org.apache.axis.client.Call;
import org.apache.axis.constants.Style;
import org.apache.axis.constants.Use;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.description.ParameterDesc;

import javax.xml.namespace.QName;
import javax.xml.rpc.Service;
import java.io.IOException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.Enumeration;

import static com.efgh.gecolsa.jobs.polnal.client.ConfigValues.NAMESPACE_URL;
import static org.apache.axis.AxisEngine.PROP_DOMULTIREFS;
import static org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS;
import static org.apache.axis.utils.JavaUtils.convert;

public class PolNalStub extends org.apache.axis.client.Stub implements PolNalSoap {

    private static OperationDesc[] _operations;

    static {
        _operations = new OperationDesc[6];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1() {
        OperationDesc oper;
        ParameterDesc param;
        oper = new OperationDesc();
        oper.setName("ValIngreso");
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PUSUARIOPROV"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PCLAVEPROV"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PNUMEROVALIDO"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(String.class);
        oper.setReturnQName(new QName(NAMESPACE_URL, "ValIngresoResult"));
        oper.setStyle(Style.WRAPPED);
        oper.setUse(Use.LITERAL);
        _operations[0] = oper;

        oper = new OperationDesc();
        oper.setName("MqaConsDispAVL");
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PUSUARIO"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PTOKEN"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PMQASERIE"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PMQAMOTOR"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PMQACHASIS"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PDISIMEI"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PTIDPROV"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PIDEPROV"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(String.class);
        oper.setReturnQName(new QName(NAMESPACE_URL, "MqaConsDispAVLResult"));
        oper.setStyle(Style.WRAPPED);
        oper.setUse(Use.LITERAL);
        _operations[1] = oper;

        oper = new OperationDesc();
        oper.setName("InsertarUbicacion");
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PUSUARIO"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PTOKEN"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PIDTRAMA"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PIDUNIDAD"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PTIPTRANSM"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PLONGITUD"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PLATITUD"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PVELOCIDAD"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PDIRECCION"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PFECHAGPS"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PEVENTO"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PIGNICION"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PIP"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PPUERTO"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PSTATUS"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PODOMETRO"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(String.class);
        oper.setReturnQName(new QName(NAMESPACE_URL, "InsertarUbicacionResult"));
        oper.setStyle(Style.WRAPPED);
        oper.setUse(Use.LITERAL);
        _operations[2] = oper;

        oper = new OperationDesc();
        oper.setName("InsertarUnidadesdeRastreo");
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PUSUARIO"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PTOKEN"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PIDUNIDAD"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PCODIMARCA"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PCODILINEA"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PIMEI"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PTARJETA_SIM"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PNRO_MOVIL"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "POPERADORMOVIL"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "POPERADORSATELITAL"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "POBSERVACION"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PSERIE_DISPOSITIVO"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(String.class);
        oper.setReturnQName(new QName(NAMESPACE_URL, "InsertarUnidadesdeRastreoResult"));
        oper.setStyle(Style.WRAPPED);
        oper.setUse(Use.LITERAL);
        _operations[3] = oper;

        oper = new OperationDesc();
        oper.setName("InsertarMaquinas");
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PUSUARIO"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PTOKEN"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PIDRUNT"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PSERIE"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PCODIMARCA"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PCODILINEA"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PMODELO"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PTIPOMAQUINA"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PIDUNIDADVIGENTE"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PMOTOR"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PCHASIS"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PTIPOUNIDADMAQUINA"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(String.class);
        oper.setReturnQName(new QName(NAMESPACE_URL, "InsertarMaquinasResult"));
        oper.setStyle(Style.WRAPPED);
        oper.setUse(Use.LITERAL);
        _operations[4] = oper;

        oper = new OperationDesc();
        oper.setName("RelacionMaquinaUnidad");
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PUSUARIO"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PTOKEN"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PMAQUINAIDRUNT"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PUNIDRASTIDUNIDAD"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new ParameterDesc(new QName(NAMESPACE_URL, "PDOCUMENTOINSTALACIONA"), ParameterDesc.IN, new QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(String.class);
        oper.setReturnQName(new QName(NAMESPACE_URL, "RelacionMaquinaUnidadResult"));
        oper.setStyle(Style.WRAPPED);
        oper.setUse(Use.LITERAL);
        _operations[5] = oper;
    }


    PolNalStub(URL endpointURL, Service service) {
        this(service);
        super.cachedEndpoint = endpointURL;
    }

    private PolNalStub(Service service) {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service) super.service).setTypeMappingVersion("1.2");
    }

    private Call createCall() throws RemoteException {
        try {
            Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                String key = (String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            return _call;
        } catch (Throwable _t) {
            throw new AxisFault("Failure trying to get the Call object", _t);
        }
    }

    private Call prepareCall(OperationDesc operation, String soapURL, String operationName) throws RemoteException {

        if (super.cachedEndpoint == null) {
            throw new NoEndPointException();
        }

        Call _call = createCall();
        _call.setUseSOAPAction(true);
        _call.setEncodingStyle(null);
        _call.setProperty(Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(SOAP11_CONSTANTS);
        _call.setOperation(operation);
        _call.setSOAPActionURI(soapURL);
        _call.setOperationName(new QName(NAMESPACE_URL, operationName));
        setRequestHeaders(_call);
        setAttachments(_call);
        return _call;
    }

    private String invokeService(Object[] parameters, Call _call) throws RemoteException {
        Object _resp = _call.invoke(parameters);

        if (_resp instanceof RemoteException) {
            throw (RemoteException) _resp;
        } else {
            extractAttachments(_call);
            try {
                return (String) _resp;
            } catch (Exception _exception) {
                return (String) convert(_resp, String.class);
            }
        }
    }

    public PolNalResponses.Validation valIngreso(String PUSUARIOPROV, String PCLAVEPROV, String PNUMEROVALIDO) throws IOException {
        Call _call = prepareCall(_operations[0], "http://policia.gov.co/webservice/ValIngreso", "ValIngreso");
        return PolNalResponses.Validation.parse(invokeService(new Object[]{PUSUARIOPROV, PCLAVEPROV, PNUMEROVALIDO}, _call));
    }

    public PolNalResponses.EntitiesInsertion mqaConsDispAVL(String PUSUARIO, String PTOKEN, String PMQASERIE, String PMQAMOTOR, String PMQACHASIS, String PDISIMEI, String PTIDPROV, String PIDEPROV) throws RemoteException {
        Call _call = prepareCall(_operations[1], "http://policia.gov.co/webservice/MqaConsDispAVL", "MqaConsDispAVL");
        return PolNalResponses.EntitiesInsertion.parse(invokeService(new Object[]{PUSUARIO, PTOKEN, PMQASERIE, PMQAMOTOR, PMQACHASIS, PDISIMEI, PTIDPROV, PIDEPROV}, _call));
    }

    public PolNalResponses.EntitiesInsertion insertarUbicacion(String PUSUARIO, String PTOKEN, String PIDTRAMA, String PIDUNIDAD, String PTIPTRANSM, String PLONGITUD, String PLATITUD, String PVELOCIDAD, String PDIRECCION, String PFECHAGPS, String PEVENTO, String PIGNICION, String PIP, String PPUERTO, String PSTATUS, String PODOMETRO) throws RemoteException {
        Call _call = prepareCall(_operations[2], "http://policia.gov.co/webservice/InsertarUbicacion", "InsertarUbicacion");
        return PolNalResponses.EntitiesInsertion.parse(invokeService(new Object[]{PUSUARIO, PTOKEN, PIDTRAMA, PIDUNIDAD, PTIPTRANSM, PLONGITUD, PLATITUD, PVELOCIDAD, PDIRECCION, PFECHAGPS, PEVENTO, PIGNICION, PIP, PPUERTO, PSTATUS, PODOMETRO}, _call));
    }

    public PolNalResponses.EntitiesInsertion insertarUnidadesdeRastreo(String PUSUARIO, String PTOKEN, String PIDUNIDAD, String PCODIMARCA, String PCODILINEA, String PIMEI, String PTARJETA_SIM, String PNRO_MOVIL, String POPERADORMOVIL, String POPERADORSATELITAL, String POBSERVACION, String PSERIE_DISPOSITIVO) throws RemoteException {
        Call _call = prepareCall(_operations[3], "http://policia.gov.co/webservice/InsertarUnidadesdeRastreo", "InsertarUnidadesdeRastreo");
        return PolNalResponses.EntitiesInsertion.parse(invokeService(new Object[]{PUSUARIO, PTOKEN, PIDUNIDAD, PCODIMARCA, PCODILINEA, PIMEI, PTARJETA_SIM, PNRO_MOVIL, POPERADORMOVIL, POPERADORSATELITAL, POBSERVACION, PSERIE_DISPOSITIVO}, _call));
    }

    public PolNalResponses.EntitiesInsertion insertarMaquinas(String PUSUARIO, String PTOKEN, String PIDRUNT, String PSERIE, String PCODIMARCA, String PCODILINEA, String PMODELO, String PTIPOMAQUINA, String PIDUNIDADVIGENTE, String PMOTOR, String PCHASIS, String PTIPOUNIDADMAQUINA) throws RemoteException {
        Call _call = prepareCall(_operations[4], "http://policia.gov.co/webservice/InsertarMaquinas", "InsertarMaquinas");
        return PolNalResponses.EntitiesInsertion.parse(invokeService(new Object[]{PUSUARIO, PTOKEN, PIDRUNT, PSERIE, PCODIMARCA, PCODILINEA, PMODELO, PTIPOMAQUINA, PIDUNIDADVIGENTE, PMOTOR, PCHASIS, PTIPOUNIDADMAQUINA}, _call));
    }

    public PolNalResponses.RelationsInsertion relacionMaquinaUnidad(String PUSUARIO, String PTOKEN, String PMAQUINAIDRUNT, String PUNIDRASTIDUNIDAD, String PDOCUMENTOINSTALACIONA) throws RemoteException {
        Call _call = prepareCall(_operations[5], "http://policia.gov.co/webservice/RelacionMaquinaUnidad", "RelacionMaquinaUnidad");
        return PolNalResponses.RelationsInsertion.parse(invokeService(new Object[]{PUSUARIO, PTOKEN, PMAQUINAIDRUNT, PUNIDRASTIDUNIDAD, PDOCUMENTOINSTALACIONA}, _call));
    }

}
