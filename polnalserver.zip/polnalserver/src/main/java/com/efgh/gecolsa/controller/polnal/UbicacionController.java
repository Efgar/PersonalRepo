package com.efgh.gecolsa.controller.polnal;

import com.efgh.gecolsa.model.jpa.entity.Ubicacion;
import com.efgh.gecolsa.service.UbicacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/v1.0/ubicacion")
public class UbicacionController {

    private final UbicacionService ubicacionService;

    @Autowired
    public UbicacionController(UbicacionService ubicacionService) {
        this.ubicacionService = ubicacionService;
    }

    @PostMapping
    public Ubicacion insertMachineLocation(@RequestBody Ubicacion ubicacion) throws IOException {
        return ubicacionService.insertLocation(ubicacion);
    }

    @GetMapping
    public List<Ubicacion> getMachineLocations(@RequestParam(defaultValue = "0") int page) {
        return ubicacionService.getLocations(page);
    }

    @GetMapping("/{idLocation}")
    public Ubicacion getMachineLocation(@PathVariable String idLocation) {
        return ubicacionService.getLocation(idLocation);
    }
}
