package com.efgh.gecolsa.model.jpa.entity;

import com.efgh.gecolsa.model.jpa.entity.Enums.SentStatus;
import com.efgh.gecolsa.model.jpa.entity.Enums.TransmissionType;
import com.efgh.gecolsa.model.jpa.entity.validation.AlphanumericWithSpaces;
import com.efgh.gecolsa.model.jpa.entity.validation.Numeric;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@Entity(name = "equipo")
public class Equipo {

    @Id
    @Column(name="id_equipo")
    String id_equipo;

    @AlphanumericWithSpaces
    @Column(name="id_runt")
    String id_runt = "NO REPORTA";

    @Column(name="idm_equipo")
    String idm_equipo = "PIDNO1";

    @Numeric
    @Column(name="tipomaquin")
    String tipomaquin = "0";

    @AlphanumericWithSpaces
    @Column(name="seriemaq")
    String seriemaq = "NO APLICA";

    @AlphanumericWithSpaces
    @Column(name="motor")
    String motor = "NO APLICA";

    @AlphanumericWithSpaces
    @Column(name="chasis")
    String chasis = "NO APLICA";

    @Column(name="tipounidad")
    TransmissionType tipounidad = TransmissionType.DL;

    @AlphanumericWithSpaces(maxLength = 20)
    @Column(name="id_unidad_vigente")
    String id_unidad_vigente = "NO APLICA";

    @Column(name="orden_trabajo")
    String orden_trabajo;

    @Column(name="contrato")
    String contrato;

    @Column(name="usuario")
    String usuario;

    @Column(name="fecha")
    LocalDateTime fecha;

    @Column(name="hora")
    LocalTime hora;

    @Column(name="reportar")
    Reportable reportar;

    @Column(name="estado")
    SentStatus estado;

    @Column(name="ultima_fecha")
    LocalDateTime ultima_fecha;

    @ManyToOne
    @JoinColumn(name="codigo_marca")
    Marca marca;

    @ManyToOne
    @JoinColumn(name="codigo_linea")
    Linea linea;

    @ManyToOne
    @JoinColumn(name="id_modelo")
    Modelo modelo;

    public enum Reportable{
        V,
        F;
    }
}
