package com.efgh.gecolsa.jobs.visionlink.Entities;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@Data
@XmlRootElement(name = "Link")
@XmlAccessorType(XmlAccessType.FIELD)
class NavigationLink {

    @XmlAttribute(name = "rel")
    String rel;

    @XmlAttribute(name = "href")
    String href;
}
