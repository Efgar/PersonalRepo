package com.efgh.gecolsa.jobs.visionlink;

import com.efgh.gecolsa.jobs.visionlink.Entities.Navigable;
import org.apache.tomcat.util.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

class NavigableHelper<T extends Navigable> {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String resourceUrl;
    private String visionLinkUser;
    private String visionLinkPass;

    private Class<T> type;

    NavigableHelper(Class<T> type, String resouceUrl, String user, String pass) {
        resourceUrl = resouceUrl;
        visionLinkUser = user;
        visionLinkPass = pass;
        this.type = type;
    }

    List<T> getPages() {
        List<T> objectList = new ArrayList<>();
        T lastInvocationResponse;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = createHeaders(visionLinkUser, visionLinkPass);
        //do {
        logger.info(String.format("Obteniendo pagina numero %s [%s]", objectList.size(), resourceUrl));
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                throw new RuntimeException("Error introduciendo delay en la invocacion");
            }
        lastInvocationResponse = restTemplate.exchange(resourceUrl, HttpMethod.GET, new HttpEntity<>(headers), type).getBody();
        Assert.notNull(lastInvocationResponse, "llamado invalido recuperando informacion de vision link");
        resourceUrl = lastInvocationResponse.getNextPageLink();
            objectList.add(lastInvocationResponse);
        //} while (!lastInvocationResponse.isLastPage());
        return objectList;
    }

    private HttpHeaders createHeaders(String username, String password) {
        HttpHeaders headers = new HttpHeaders() {{
            String auth = username + ":" + password;
            byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
            String authHeader = "Basic " + new String(encodedAuth);
            set("Authorization", authHeader);
        }};
        return headers;
    }

}
