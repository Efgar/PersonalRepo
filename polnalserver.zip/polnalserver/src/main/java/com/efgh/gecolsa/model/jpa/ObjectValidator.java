package com.efgh.gecolsa.model.jpa;

import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.io.IOException;
import java.util.Set;

@Component
public class ObjectValidator {
    private ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
    private Validator validator = factory.getValidator();

    /**
     * Validates an object and throws an exception if there is an error.
     *
     * @param objectName Object name to identify the validated entity
     * @param objectIdentifier Object identifier
     * @param objectToValidate Object to validate
     * @throws IOException if there is a validation error in the object
     */
    public void validate(String objectName, String objectIdentifier, Object objectToValidate) throws IOException {
        Set<ConstraintViolation<Object>> violations = validator.validate(objectToValidate);

        if (!violations.isEmpty()) {
            StringBuffer validationErrors = new StringBuffer("Objeto invalido::").append(objectName).append(String.format("[%s]", objectIdentifier));
            violations.forEach(constraintViolation -> validationErrors.append("\n\t > ").append(constraintViolation.getPropertyPath()).append("::").append(constraintViolation.getMessage()));
            throw new IOException(validationErrors.toString());
        }
    }
}
