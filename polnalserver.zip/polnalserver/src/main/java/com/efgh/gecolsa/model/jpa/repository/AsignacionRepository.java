package com.efgh.gecolsa.model.jpa.repository;

import com.efgh.gecolsa.model.jpa.entity.Asignacion;
import com.efgh.gecolsa.model.jpa.entity.Enums.SentStatus;
import com.efgh.gecolsa.model.jpa.entity.UnidadRastreo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AsignacionRepository extends JpaRepository<Asignacion, Long> {
    List<Asignacion> findByEstadoEnvio(SentStatus estadoEnvio);

    @Query("SELECT asign.unidad FROM Asignacion asign WHERE asign.equipo.id_equipo = :equipoId")
    UnidadRastreo findActiveUnitForEquipo(@Param("equipoId") String equipoId);
}
