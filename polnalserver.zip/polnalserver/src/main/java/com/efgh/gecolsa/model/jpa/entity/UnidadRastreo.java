package com.efgh.gecolsa.model.jpa.entity;

import com.efgh.gecolsa.model.jpa.entity.validation.Alphanumeric;
import com.efgh.gecolsa.model.jpa.entity.validation.AlphanumericWithSpaces;
import com.efgh.gecolsa.model.jpa.entity.validation.Numeric;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@Entity(name = "unidad")
public class UnidadRastreo {

    @Alphanumeric(maxLength = 20)
    @Id
    @Column(name="id_unidad")
    String id_unidad;

    @AlphanumericWithSpaces(maxLength = 80)
    @Column(name="serie_dispositivo")
    String serie_dispositivo = "NO APLICA";

    @Numeric
    @Column(name="imei")
    String imei = "0";

    @Numeric
    @Column(name="tarjeta_sim")
    String tarjeta_sim = "0";

    @Numeric
    @Column(name="numero_movil")
    String numero_movil = "0";

    @AlphanumericWithSpaces(maxLength = 40)
    @Column(name="opera_movil")
    String opera_movil = "NO APLICA";

    @AlphanumericWithSpaces(maxLength = 40)
    @Column(name="opera_satel")
    String opera_satel = "NO APLICA";

    @AlphanumericWithSpaces(maxLength = 80)
    @Column(name="observacion")
    String observacion = "NO APLICA";

    @Column(name="fecunidad")
    String fecunidad;

    @Column(name="usuario")
    String usuario;

    @Column(name="fecha")
    LocalDateTime fecha;

    @Column(name="hora")
    LocalTime hora;

    @ManyToOne
    @JoinColumn(name="codigo_marca")
    Marca marca;

    @ManyToOne
    @JoinColumn(name="codigo_linea")
    Linea linea;

}
