package com.efgh.gecolsa.model.jpa.entity;

import com.efgh.gecolsa.model.jpa.entity.Enums.SentStatus;
import com.efgh.gecolsa.model.jpa.entity.validation.Alphanumeric;
import com.efgh.gecolsa.model.jpa.entity.validation.AlphanumericWithSpaces;
import com.efgh.gecolsa.model.jpa.entity.validation.Numeric;
import lombok.Data;
import org.apache.commons.lang3.ObjectUtils;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@Entity(name = "unidad")
public class UnidadRastreo {

    @Alphanumeric(maxLength = 20)
    @Id
    @Column(name="id_unidad")
    private String id_unidad;

    @AlphanumericWithSpaces(maxLength = 80)
    @Column(name="serie_dispositivo")
    private String serie_dispositivo = "NO APLICA";

    @Numeric
    @Column(name="imei")
    private String imei = "0";

    @Numeric
    @Column(name="tarjeta_sim")
    private String tarjeta_sim = "0";

    @Numeric
    @Column(name="numero_movil")
    private String numero_movil = "0";

    @AlphanumericWithSpaces(maxLength = 40)
    @Column(name="opera_movil")
    private String opera_movil = "NO APLICA";

    @AlphanumericWithSpaces(maxLength = 40)
    @Column(name="opera_satel")
    private String opera_satel = "NO APLICA";

    @AlphanumericWithSpaces(maxLength = 80)
    @Column(name="observacion")
    private String observacion = "NO APLICA";

    @Column(name="fecunidad")
    private String fecunidad;

    @Column(name="usuario")
    private String usuario;

    @Column(name="enabled")
    private boolean enabled;

    @Column(name="fecha")
    private LocalDateTime fecha;

    @Column(name="hora")
    private LocalTime hora;

    @NotNull
    @Column(name = "estado_envio")
    private SentStatus estadoEnvio = Enums.SentStatus.P;

    @NotNull
    @ManyToOne
    @JoinColumn(name="id_marca")
    private Marca marca;

    @NotNull
    @ManyToOne
    @JoinColumn(name="id_linea")
    private Linea linea;

    public void updateFields(UnidadRastreo unidad) {
        this.serie_dispositivo = ObjectUtils.firstNonNull(unidad.getSerie_dispositivo(), this.serie_dispositivo);
        this.imei = ObjectUtils.firstNonNull(unidad.getImei(), this.imei);
        this.tarjeta_sim = ObjectUtils.firstNonNull(unidad.getTarjeta_sim(), this.tarjeta_sim);
        this.numero_movil = ObjectUtils.firstNonNull(unidad.getNumero_movil(), this.numero_movil);
        this.opera_satel = ObjectUtils.firstNonNull(unidad.getOpera_satel(), this.opera_satel);
        this.observacion = ObjectUtils.firstNonNull(unidad.getObservacion(), this.observacion);
        this.fecunidad = ObjectUtils.firstNonNull(unidad.getFecunidad(), this.fecunidad);
        this.usuario = ObjectUtils.firstNonNull(unidad.getUsuario(), this.usuario);
        this.fecha = ObjectUtils.firstNonNull(unidad.getFecha(), this.fecha);
        this.hora = ObjectUtils.firstNonNull(unidad.getHora(), this.hora);
        this.marca = ObjectUtils.firstNonNull(unidad.getMarca(), this.marca);
        this.linea = ObjectUtils.firstNonNull(unidad.getLinea(), this.linea);
        this.estadoEnvio = Enums.SentStatus.P;
    }

}
