package com.efgh.gecolsa.service;

import com.efgh.gecolsa.model.jpa.ObjectValidator;
import com.efgh.gecolsa.model.jpa.entity.Marca;
import com.efgh.gecolsa.model.jpa.repository.MarcaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class MarcaService {

    private final ObjectValidator objectValidator;

    private final MarcaRepository marcaRepo;

    @Autowired
    public MarcaService(ObjectValidator objectValidator, MarcaRepository marcaRepo) {
        this.objectValidator = objectValidator;
        this.marcaRepo = marcaRepo;
    }

    public Marca insertarMarca(Marca marca) throws IOException {
        objectValidator.validate("Marca", String.valueOf(marca.getId_marca()), marca);
        if (marca.getId_marca() != null) {
            Assert.isTrue(!marcaRepo.existsById(marca.getId_marca()), "Ya existe un objeto con el ID especificado");
        }
        marcaRepo.save(marca);
        return marca;
    }

    public List<Marca> getMarcas(int page, String code) {
        if(!StringUtils.isEmpty(code)){
            return marcaRepo.findByCod__marca__cat(code, PageRequest.of(page,20)).getContent();
        }
        return marcaRepo.findAll(PageRequest.of(page, 20)).getContent();
    }

    public Marca getMarca(Long idMarca) {
        return marcaRepo.findById(idMarca).orElseThrow(() -> new NoSuchElementException("No existe marca con el ID_MARCA especificado"));
    }
}
