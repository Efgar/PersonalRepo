package com.efgh.gecolsa.model.jpa.entity.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;

@Pattern(regexp = "([0-9]{2})/([0-9]{2})/([0-9]{4})[ ([0-9]{2}):([0-9]{2}):([0-9]{2})]*")
@NotNull
@ReportAsSingleViolation
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target( { FIELD, METHOD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Constraint(validatedBy={})
public @interface ValidDate {
    String message() default "debe ser una fecha valida en el formato (dd/MM/yyyy hh:mm:ss)";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}