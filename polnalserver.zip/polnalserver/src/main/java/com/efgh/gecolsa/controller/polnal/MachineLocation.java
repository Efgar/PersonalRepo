package com.efgh.gecolsa.controller.polnal;

import com.efgh.gecolsa.model.jpa.entity.Ubicacion;
import com.efgh.gecolsa.service.MachineLocationService;
import com.efgh.gecolsa.service.MailHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/v1.0/machines/location")
public class MachineLocation {

    private final MachineLocationService machineLocationService;

    @Autowired
    public MachineLocation(MachineLocationService machineLocationService) {
        this.machineLocationService = machineLocationService;
    }

    @PostMapping
    public void insertMachineLocation(@RequestBody Ubicacion ubicacion) throws IOException {
        machineLocationService.insertMachineLocation(ubicacion);
    }

    @GetMapping
    public List<Ubicacion> getMachineLocations(@RequestParam int locationsAmount) throws IOException {
        return machineLocationService.getMachineLocations(locationsAmount);
    }
}
