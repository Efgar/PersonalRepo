package com.efgh.gecolsa.jobs.polnal.client;

import java.io.IOException;

public class PolNalResponses {

    public interface PolnalResponse{
        boolean isOk();
        boolean isDuplicated();
        String getCode();
        String getMessage();

    }

    public enum Validation implements PolnalResponse{
        OK("00", "Ok"),
        PROVEEDOR_NO_COINCIDE("01", "El proveedor ingresado no coincide."),
        SERIAL_NO_COINCIDE("02", "El Serial ingresado no coincide."),
        MOTOR_NO_COINCIDE("03", "El motor ingresado no coincide."),
        CHASIS_NO_COINCIDE("04", "El Chasis ingresado no coincide"),
        IMEI_NO_COINCIDE("05", "El IMEI ingresado no coincide"),
        SERIE_NO_COINCIDE("06", "El numero de serie ingresado no coincide"),
        IMEI_NO_REGISTRADO("07", "El IMER ingresado no esta registrado"),
        MAQUINA_NO_REGISTRADA("08", "La maquina no esta registrada"),
        NO_DATOS_SUFICIENTES_PARA_PROCESAR("99", "No se cuenta con datos suficientes para efectuar el proceso");

        public String code;
        public String message;
        public String token;

        Validation(String code, String message) {
            this.code = code;
            this.message = message;
        }

        static Validation parse(String callResponse) throws IOException {
            String[] serviceCallSplit = callResponse.split(";");
            if (serviceCallSplit.length >= 2) {
                String token = serviceCallSplit[0];
                String result = serviceCallSplit[1];
                Validation validation = getResponseFromCode(result);
                validation.token = token;
                return validation;
            }
            throw new IOException("Llamado al servicio de validacion no pudo ser realizado, el resultado no tiene la estructura esperada (XX;XX)");
        }

        private static Validation getResponseFromCode(String code) {
            Validation match = null;
            for (Validation aux : Validation.values()) {
                if (aux.code.equals(code)) {
                    match = aux;
                    break;
                }
            }
            return match;
        }

        @Override
        public boolean isOk(){
            return code.equalsIgnoreCase(Validation.OK.code) && token != null && !token.equalsIgnoreCase("0");
        }

        @Override
        public boolean isDuplicated() {
            return false;
        }

        @Override
        public String getCode() {
            return code;
        }

        @Override
        public String getMessage() {
            return message;
        }
    }

    public enum EntitiesInsertion  implements PolnalResponse{
        OK("002", "Ok"),
        INICIANDO_PROCESO("001", "Iniciando proceso"),
        REGISTRO_DUPLICADO("ER1", "Registro duplicado!"),
        ERROR_DE_REGISTRO("ER2", "Error en el proceso de registro"),
        TOKEN_NO_COINCIDE("ER3", "Token expirado"),
        UNDEFINED("", "Error indefinido");

        public String codePrefix;
        public String message;

        EntitiesInsertion(String codePrefix, String message) {
            this.codePrefix = codePrefix;
            this.message = message;
        }

        static EntitiesInsertion parse(String callResponse) {
            EntitiesInsertion match = EntitiesInsertion.UNDEFINED;
            if (callResponse != null) {
                for (EntitiesInsertion aux : EntitiesInsertion.values()) {
                    if (callResponse.trim().startsWith(aux.codePrefix)) {
                        match = aux;
                        break;
                    }
                }
            }
            return match;
        }

        @Override
        public boolean isDuplicated(){
            return this.codePrefix.equalsIgnoreCase(EntitiesInsertion.REGISTRO_DUPLICADO.codePrefix);
        }

        @Override
        public boolean isOk(){
            return this.codePrefix.equalsIgnoreCase(EntitiesInsertion.OK.codePrefix);
        }

        @Override
        public String getCode() {
            return codePrefix;
        }

        @Override
        public String getMessage() {
            return message;
        }
    }

    public enum RelationsInsertion  implements PolnalResponse{
        OK("002", "Ok"),
        INICIANDO_PROCESO("001", "Iniciando proceso"),
        REGISTRO_DUPLICADO("ER1", "Registro duplicado!"),
        ERROR_DE_REGISTRO("ER2", "Error en el proceso de registro"),
        TOKEN_NO_COINCIDE("ER3", "Token expirado"),
        UNDEFINED("", "Error indefinido");

        public String codePrefix;
        public String message;

        RelationsInsertion(String codePrefix, String message) {
            this.codePrefix = codePrefix;
            this.message = message;
        }

        static RelationsInsertion parse(String callResponse) {
            RelationsInsertion match = RelationsInsertion.UNDEFINED;
            if (callResponse != null) {
                for (RelationsInsertion aux : RelationsInsertion.values()) {
                    if (callResponse.trim().startsWith(aux.codePrefix)) {
                        match = aux;
                        break;
                    }
                }
            }
            return match;
        }

        @Override
        public boolean isOk(){
            return this.codePrefix.equalsIgnoreCase(RelationsInsertion.OK.codePrefix);
        }

        @Override
        public boolean isDuplicated() {
            return this.codePrefix.equalsIgnoreCase(EntitiesInsertion.REGISTRO_DUPLICADO.codePrefix);
        }

        @Override
        public String getCode() {
            return codePrefix;
        }

        @Override
        public String getMessage() {
            return message;
        }
    }
}
