package com.efgh.gecolsa.service;

import com.efgh.gecolsa.commons.Translator;
import com.efgh.gecolsa.model.jpa.ObjectValidator;
import com.efgh.gecolsa.model.jpa.entity.Ubicacion;
import com.efgh.gecolsa.model.jpa.repository.UbicacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class UbicacionService {

    private final ObjectValidator objectValidator;

    private final UbicacionRepository ubicacionRepo;

    @Autowired
    Translator translator;

    @Autowired
    public UbicacionService(ObjectValidator objectValidator, UbicacionRepository ubicacionRepo) {
        this.objectValidator = objectValidator;
        this.ubicacionRepo = ubicacionRepo;
    }

    public Ubicacion insertLocation(Ubicacion ubicacion) throws IOException {
        objectValidator.validate("Ubicacion", ubicacion.getId_trama(), ubicacion);
        Assert.isTrue(!ubicacionRepo.existsById(ubicacion.getId_trama()), "Ya existe una ubicacion con el ID especificado");
        ubicacionRepo.save(ubicacion);
        return ubicacion;
    }

    public List<Ubicacion> getLocations(int page) {
        return ubicacionRepo.findAll(PageRequest.of(page, 20)).getContent();
    }

    public Ubicacion getLocation(String locationID) {
        return ubicacionRepo.findById(locationID).orElseThrow(() -> new NoSuchElementException("No existe ubicacion con el ID-TRAMA especificado"));
    }
}
