package com.efgh.gecolsa.jobs.visionlink.Entities;

import lombok.Data;

import javax.xml.bind.annotation.*;

@Data
@XmlRootElement(name = "Asset")
@XmlAccessorType(XmlAccessType.FIELD)
public class Asset {

    @XmlAttribute(name = "url")
    String url;

    @XmlElement(name = "VisionLinkIdentifier")
    String visionLinkIdentifier;

    @XmlElement(name = "MakeCode")
    String makeCode;

    @XmlElement(name = "MakeName")
    String makeName;

    @XmlElement(name = "SerialNumber")
    String serialNumber;

    @XmlElement(name = "AssetID")
    String assetID;

    @XmlElement(name = "Model")
    String model;

    @XmlElement(name = "ProductFamily")
    String productFamily;

    @XmlElement(name = "ManufactureYear")
    String manufactureYear;

    @XmlElement(name = "DeviceType")
    String deviceType;

    @XmlElement(name = "DeviceSerialNumber")
    String deviceSerialNumber;

}
