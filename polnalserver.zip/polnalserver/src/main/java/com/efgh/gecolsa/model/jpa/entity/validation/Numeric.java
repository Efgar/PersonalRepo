package com.efgh.gecolsa.model.jpa.entity.validation;

import javax.validation.Constraint;
import javax.validation.OverridesAttribute;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.Long.MAX_VALUE;
import static java.lang.annotation.ElementType.*;

@Pattern(regexp = "^[0-9]*$")
@Max(value = MAX_VALUE)
@Size
@NotNull
@ReportAsSingleViolation
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target( { FIELD, METHOD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Constraint(validatedBy={})
public @interface Numeric {
    String message() default "debe ser numérico, con valor máximo {maxValue} y longitud máxima {maxLength}";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};

    @OverridesAttribute(constraint= Max.class, name="value")
    long maxValue() default MAX_VALUE;

    @OverridesAttribute(constraint= Size.class, name="max")
    int maxLength() default Integer.MAX_VALUE;
}