package com.efgh.gecolsa.model.jpa.repository;

import com.efgh.gecolsa.model.jpa.entity.Enums.SentStatus;
import com.efgh.gecolsa.model.jpa.entity.UnidadRastreo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UnidadRastreoRepository extends JpaRepository<UnidadRastreo, String> {
    List<UnidadRastreo> findByEstadoEnvio(SentStatus estadoEnvio);
}
