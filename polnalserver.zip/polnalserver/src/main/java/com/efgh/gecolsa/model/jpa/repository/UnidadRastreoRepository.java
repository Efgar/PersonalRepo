package com.efgh.gecolsa.model.jpa.repository;

import com.efgh.gecolsa.model.jpa.entity.UnidadRastreo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UnidadRastreoRepository extends JpaRepository<UnidadRastreo, String> {
}
