package com.efgh.gecolsa.service;

import com.efgh.gecolsa.commons.Translator;
import com.efgh.gecolsa.model.jpa.ObjectValidator;
import com.efgh.gecolsa.model.jpa.entity.UnidadRastreo;
import com.efgh.gecolsa.model.jpa.repository.UnidadRastreoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class UnidadRastreoService {

    private final ObjectValidator objectValidator;

    private final UnidadRastreoRepository unidadRastreoRepo;

    @Autowired
    Translator translator;

    @Autowired
    public UnidadRastreoService(ObjectValidator objectValidator, UnidadRastreoRepository unidadRastreoRepo) {
        this.objectValidator = objectValidator;
        this.unidadRastreoRepo = unidadRastreoRepo;
    }

    public UnidadRastreo updateUnidadRastreo(String idUnidad, UnidadRastreo unidadRastreo) throws IOException {
        UnidadRastreo unidad = unidadRastreoRepo.findById(idUnidad).orElseThrow(() -> new NoSuchElementException("No existe unidad con el ID-UNIDAD especificado"));
        unidad.updateFields(unidadRastreo);
        objectValidator.validate("Ubicacion", unidad.getId_unidad(), unidadRastreo);
        unidadRastreoRepo.save(unidad);
        return unidad;
    }

    public List<UnidadRastreo> getUnidadesRastreo(int page) {
        return unidadRastreoRepo.findAll(PageRequest.of(page, 20)).getContent();
    }

    public UnidadRastreo getUnidadRastreo(String unidadId) {
        return unidadRastreoRepo.findById(unidadId).orElseThrow(() -> new NoSuchElementException("No existe unidad con el ID-UNIDAD especificado"));
    }

    public UnidadRastreo changeEnablingStatusUnidadRastreo(String idUnidad, boolean status) {
        UnidadRastreo unidad = unidadRastreoRepo.findById(idUnidad).orElseThrow(() -> new NoSuchElementException("No existe unidad con el ID-UNIDAD especificado"));
        unidad.setEnabled(status);
        unidadRastreoRepo.save(unidad);
        return unidad;
    }
}
