package com.efgh.gecolsa.model.jpa.entity;

import com.efgh.gecolsa.model.jpa.entity.validation.Numeric;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Data
@Entity(name = "linea")
public class Linea {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="id_linea")
    Long id_linea;

    @Numeric
    @Column(name = "cod_linea_cat")
    String codLineaCat = "0";

    @NotNull
    @Column(name="desc_linea")
    String desc_linea = "";
}
