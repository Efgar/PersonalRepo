package com.efgh.gecolsa.model.jpa.entity;

import com.efgh.gecolsa.model.jpa.entity.validation.Numeric;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity(name = "linea")
public class Linea {

    @Id
    @Column(name="id_linea")
    String id_linea;

    @Column(name="desc_linea")
    String desc_linea;

    @Numeric
    @Column(name="cod_linea_cat")
    String cod_linea_cat = "0";
}
