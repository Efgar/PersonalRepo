package com.efgh.gecolsa.model.jpa.entity;

import com.efgh.gecolsa.model.jpa.entity.validation.Numeric;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity(name = "modelo")
public class Modelo {

    @Id
    @Column(name="id_modelo")
    String id_modelo;

    @Numeric(maxLength = 4)
    @Column(name="cod_modelo")
    String cod_modelo = "0";

    @Column(name="desc_modelo")
    String desc_modelo;
}
