package com.efgh.gecolsa.jobs.polnal;

import com.efgh.gecolsa.commons.Translator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.List;

@Component
public class PolnalJob {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    PolnalClient polnalClient;

    @Value("${gecolsa.policiagps.general.user}")
    String user;

    @Value("${gecolsa.policiagps.general.password}")
    String password;

    @Value("${gecolsa.policiagps.general.uniquekey}.split(',')")
    List<String> validKeys;

    private Integer currentValidKeyInUse = 0;

    @Autowired
    Translator translator;

    @Scheduled(cron = "${gecolsa.policiagps.general.cron}")
    public void sendRegistriesToPolnal(){
        logger.info(translator.translate("efgh.polnal.logger.separator"));
        logger.info("INICIANDO PROCESAMIENTO DE MAQUINAS");
        logger.info(translator.translate("efgh.polnal.logger.separator"));
        String token = getValidToken();
        if(!StringUtils.isEmpty(token)){

        }
        logger.info(translator.translate("efgh.polnal.logger.separator"));
        logger.info("FINALIZANDO PROCESAMIENTO DE MAQUINAS");
        logger.info(translator.translate("efgh.polnal.logger.separator"));
    }

    private String getValidToken() {
        int retriesAmount = 0;
        Exception currentException = null;
        while(retriesAmount < 10){
            try {
                Thread.sleep(retriesAmount*10000);
                return polnalClient.getToken(user, password, validKeys.get(currentValidKeyInUse), retriesAmount == 9);
            } catch (Exception e) {
                increaseCurrentValidKey();
                retriesAmount++;
                currentException = e;
            }
        }
        logger.error("ERROR OBTENIENDO TOKEN", currentException);
        return null;
    }

    private void increaseCurrentValidKey(){
        currentValidKeyInUse ++;
        if(currentValidKeyInUse >= validKeys.size()){
            currentValidKeyInUse = 0;
        }
    }
}
