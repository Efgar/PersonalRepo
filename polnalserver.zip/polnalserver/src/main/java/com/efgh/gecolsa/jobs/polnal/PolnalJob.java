package com.efgh.gecolsa.jobs.polnal;

import com.efgh.gecolsa.commons.Translator;
import com.efgh.gecolsa.model.jpa.entity.Asignacion;
import com.efgh.gecolsa.model.jpa.entity.Enums.SentStatus;
import com.efgh.gecolsa.model.jpa.entity.Equipo;
import com.efgh.gecolsa.model.jpa.entity.Ubicacion;
import com.efgh.gecolsa.model.jpa.entity.UnidadRastreo;
import com.efgh.gecolsa.model.jpa.repository.AsignacionRepository;
import com.efgh.gecolsa.model.jpa.repository.EquipoRepository;
import com.efgh.gecolsa.model.jpa.repository.UbicacionRepository;
import com.efgh.gecolsa.model.jpa.repository.UnidadRastreoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class PolnalJob {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private PolnalClient polnalClient;

    @Value("${gecolsa.policiagps.general.user}")
    private String user;

    @Value("${gecolsa.policiagps.general.password}")
    private String password;

    @Value("${gecolsa.policiagps.general.uniquekey}.split(',')")
    private List<String> validKeys;

    @Autowired
    private Translator translator;

    @Autowired
    private UnidadRastreoRepository unidadRastreoRepo;

    @Autowired
    private EquipoRepository equipoRepo;

    @Autowired
    private AsignacionRepository asignacionRepo;

    @Autowired
    private UbicacionRepository ubicacionRepo;

    private Integer currentValidKeyInUse = 0;

    //@Scheduled(cron = "${gecolsa.policiagps.general.cron}")
    public void sendRegistriesToPolnal() {
        logger.info(translator.translate("efgh.polnal.logger.separator"));
        logger.info( translator.translate("efgh.polnal.job.send.process"));
        logger.info(translator.translate("efgh.polnal.logger.separator"));
        String token = getValidToken();

        if (!StringUtils.isEmpty(token)) {
            sendUnidadesRastreo(token);
            sendEquipos(token);
            sendAsignaciones(token);
            sendUbicaciones(token);
        }

        logger.info(translator.translate("efgh.polnal.logger.separator"));
        logger.info(translator.translate("efgh.polnal.job.ended.process"));
        logger.info(translator.translate("efgh.polnal.logger.separator"));
    }

    private String getValidToken() {
        int retriesAmount = 0;
        Exception currentException = null;
        while (retriesAmount < 10) {
            try {
                Thread.sleep(retriesAmount * 10000);
                return polnalClient.getToken(user, password, validKeys.get(currentValidKeyInUse), retriesAmount >= 9);
            } catch (Exception e) {
                increaseCurrentValidKey();
                retriesAmount++;
                currentException = e;
            }
        }
        logger.error( translator.translate("efgh.polnal.job.error.token"), currentException);
        return null;
    }

    private void sendUnidadesRastreo(String token) {
        AtomicInteger updatedCount = new AtomicInteger();
        List<UnidadRastreo> unidadesRastreo = unidadRastreoRepo.findByEstadoEnvio(SentStatus.P);
        logger.info(String.format( translator.translate("efgh.polnal.job.send.update.units"), unidadesRastreo.size()));
        unidadesRastreo.forEach(unidad -> {
            if (polnalClient.insertTrackingUnit(user, token, unidad)) {
                unidad.setEstadoEnvio(SentStatus.T);
                updatedCount.getAndIncrement();
            }
        });
        logger.info(String.format( translator.translate("efgh.polnal.job.send.update.units.bd"), updatedCount));
        unidadRastreoRepo.saveAll(unidadesRastreo);
    }

    private void sendEquipos(String token) {
        AtomicInteger updatedCount = new AtomicInteger();
        List<Equipo> entitiesList = equipoRepo.findByEstadoEnvio(SentStatus.P);
        logger.info(String.format(translator.translate("efgh.polnal.job.send.update.machines"), entitiesList.size()));
        entitiesList.forEach(entity -> {
            if (polnalClient.insertMachine(user, token, entity)) {
                entity.setEstadoEnvio(SentStatus.T);
                updatedCount.getAndIncrement();
            }
        });
        logger.info(String.format( translator.translate("efgh.polnal.job.send.update.machines.bd"), updatedCount));
        equipoRepo.saveAll(entitiesList);
    }

    private void sendAsignaciones(String token) {
        AtomicInteger updatedCount = new AtomicInteger();
        List<Asignacion> entitiesList = asignacionRepo.findByEstadoEnvio(SentStatus.P);
        logger.info(String.format(translator.translate("efgh.polnal.job.send.update.assignment"), entitiesList.size()));
        entitiesList.forEach(asignacion -> {
            if (polnalClient.insertTrackingUnitMachineRelation(user, token, asignacion)) {
                asignacion.setEstadoEnvio(SentStatus.T);
                updatedCount.getAndIncrement();
            }
        });
        logger.info(String.format("ASIGNACIONES A ACTUALIZAR (BD): %s", updatedCount));
        asignacionRepo.saveAll(entitiesList);
    }

    private void sendUbicaciones(String token) {
        AtomicInteger updatedCount = new AtomicInteger();
        List<Ubicacion> entitiesList = ubicacionRepo.findByEstadoEnvio(SentStatus.P);
        logger.info(String.format( translator.translate("efgh.polnal.job.send.update.location"), entitiesList.size()));
        entitiesList.forEach(entity -> {
            if (polnalClient.insertMachineLocation(user, token, entity)) {
                entity.setEstadoEnvio(SentStatus.T);
                updatedCount.getAndIncrement();
            }
        });
        logger.info(String.format(translator.translate("efgh.polnal.job.send.update.location.bd"), updatedCount));
        ubicacionRepo.saveAll(entitiesList);
    }

    private void increaseCurrentValidKey() {
        currentValidKeyInUse++;
        if (currentValidKeyInUse >= validKeys.size()) {
            currentValidKeyInUse = 0;
        }
    }
}
