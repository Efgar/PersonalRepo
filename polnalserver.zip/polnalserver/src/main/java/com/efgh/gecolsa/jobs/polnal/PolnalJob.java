package com.efgh.gecolsa.jobs.polnal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

@Component
public class PolnalJob {

    @Autowired
    PolnalClient polnalClient;

    @Value("${gecolsa.policiagps.general.user}")
    String user;

    @Value("${gecolsa.policiagps.general.password}")
    String password;

    @Value("${gecolsa.policiagps.general.uniquekey}.split(',')")
    List<String> validKeys;

    Integer currentValidKeyInUse = 0;


    @Scheduled(cron = "${gecolsa.policiagps.general.cron}")
    public void sendRegistriesToPolnal() throws IOException {
        System.out.println(polnalClient.getToken(user, password, validKeys.get(currentValidKeyInUse)));

    }
}
