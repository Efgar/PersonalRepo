package com.efgh.gecolsa.jobs.polnal.client;

import javax.xml.rpc.ServiceException;
import javax.xml.rpc.Stub;
import java.io.IOException;
import java.rmi.RemoteException;

public class PolNalProxy implements PolNalSoap {
    private String _endpoint = null;

    private PolNalSoap service1Soap = null;

    public PolNalProxy(int timeout){
        setTimeout(timeout);
    }

    private void _initService1SoapProxy() {
        try {
            service1Soap = (new PolNalLocator()).getService1Soap();
            if (service1Soap != null) {
                if (_endpoint != null) {
                    ((Stub) service1Soap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
                } else {
                    _endpoint = (String) ((Stub) service1Soap)._getProperty("javax.xml.rpc.service.endpoint.address");
                }
            }
        } catch (ServiceException serviceException) {
            throw new IllegalStateException("Application can not access the defined endpoint for POLNAL web service");
        }
    }

    public PolNalSoap getService1Soap() {
        if (service1Soap == null) {
            _initService1SoapProxy();
        }
        return service1Soap;
    }

    public void setTimeout(int minutes){
        ((PolNalStub) getService1Soap()).setTimeout(minutes * 60000);
    }

    public PolNalResponses.Validation valIngreso(String PUSUARIOPROV, String PCLAVEPROV, String PNUMEROVALIDO) throws IOException {
        return service1Soap.valIngreso(PUSUARIOPROV, PCLAVEPROV, PNUMEROVALIDO);
    }

    public PolNalResponses.EntitiesInsertion mqaConsDispAVL(String PUSUARIO, String PTOKEN, String PMQASERIE, String PMQAMOTOR, String PMQACHASIS, String PDISIMEI, String PTIDPROV, String PIDEPROV) throws RemoteException {
        return service1Soap.mqaConsDispAVL(PUSUARIO, PTOKEN, PMQASERIE, PMQAMOTOR, PMQACHASIS, PDISIMEI, PTIDPROV, PIDEPROV);
    }

    public PolNalResponses.EntitiesInsertion insertarUbicacion(String PUSUARIO, String PTOKEN, String PIDTRAMA, String PIDUNIDAD, String PTIPTRANSM, String PLONGITUD, String PLATITUD, String PVELOCIDAD, String PDIRECCION, String PFECHAGPS, String PEVENTO, String PIGNICION, String PIP, String PPUERTO, String PSTATUS, String PODOMETRO) throws RemoteException {
        return service1Soap.insertarUbicacion(PUSUARIO, PTOKEN, PIDTRAMA, PIDUNIDAD, PTIPTRANSM, PLONGITUD, PLATITUD, PVELOCIDAD, PDIRECCION, PFECHAGPS, PEVENTO, PIGNICION, PIP, PPUERTO, PSTATUS, PODOMETRO);
    }

    public PolNalResponses.EntitiesInsertion insertarUnidadesdeRastreo(String PUSUARIO, String PTOKEN, String PIDUNIDAD, String PCODIMARCA, String PCODILINEA, String PIMEI, String PTARJETA_SIM, String PNRO_MOVIL, String POPERADORMOVIL, String POPERADORSATELITAL, String POBSERVACION, String PSERIE_DISPOSITIVO) throws RemoteException {
        return service1Soap.insertarUnidadesdeRastreo(PUSUARIO, PTOKEN, PIDUNIDAD, PCODIMARCA, PCODILINEA, PIMEI, PTARJETA_SIM, PNRO_MOVIL, POPERADORMOVIL, POPERADORSATELITAL, POBSERVACION, PSERIE_DISPOSITIVO);
    }

    public PolNalResponses.EntitiesInsertion insertarMaquinas(String PUSUARIO, String PTOKEN, String PIDRUNT, String PSERIE, String PCODIMARCA, String PCODILINEA, String PMODELO, String PTIPOMAQUINA, String PIDUNIDADVIGENTE, String PMOTOR, String PCHASIS, String PTIPOUNIDADMAQUINA) throws RemoteException {
        return service1Soap.insertarMaquinas(PUSUARIO, PTOKEN, PIDRUNT, PSERIE, PCODIMARCA, PCODILINEA, PMODELO, PTIPOMAQUINA, PIDUNIDADVIGENTE, PMOTOR, PCHASIS, PTIPOUNIDADMAQUINA);
    }

    public PolNalResponses.RelationsInsertion relacionMaquinaUnidad(String PUSUARIO, String PTOKEN, String PMAQUINAIDRUNT, String PUNIDRASTIDUNIDAD, String PDOCUMENTOINSTALACIONA) throws RemoteException {
        return service1Soap.relacionMaquinaUnidad(PUSUARIO, PTOKEN, PMAQUINAIDRUNT, PUNIDRASTIDUNIDAD, PDOCUMENTOINSTALACIONA);
    }


}