package com.efgh.gecolsa.controller.polnal;

import com.efgh.gecolsa.model.jpa.entity.Linea;
import com.efgh.gecolsa.service.LineaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/v1.0/linea")
public class LineaController {

    private final LineaService lineaService;

    @Autowired
    public LineaController(LineaService lineaService) {
        this.lineaService = lineaService;
    }

    @PostMapping
    public Linea insertarLinea(@RequestBody Linea linea) throws IOException {
        return lineaService.insertarLinea(linea);
    }

    @GetMapping
    public List<Linea> getLineas(@RequestParam(defaultValue = "0") int page, @RequestParam(required = false) String code) {
        return lineaService.getLineas(page, code);
    }

    @GetMapping("/{idLinea}")
    public Linea getLinea(@PathVariable Long idLinea) {
        return lineaService.getLinea(idLinea);
    }
}
