package com.efgh.gecolsa.jobs.visionlink.Entities;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Data
@XmlRootElement(name = "AssetOperationDate")
@XmlAccessorType(XmlAccessType.FIELD)
public class AssetOperationDateInfo implements Comparable<AssetOperationDateInfo> {
    public static final DateTimeFormatter ISO8601_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");

    @XmlElement(name = "StartStateUtc")
    String startStateUtc;
    @XmlElement(name = "StartStateAssetLocalTime")
    String startStateAssetLocalTime;
    @XmlElement(name = "StartStateAssetTimeZoneAbbrev")
    String startStateAssetTimeZoneAbbrev;
    @XmlElement(name = "StartLocation")
    AssetLocation startLocation;
    @XmlElement(name = "EndStateUtc")
    String endStateUtc;
    @XmlElement(name = "EndStateAssetLocalTime")
    String endStateAssetLocalTime;
    @XmlElement(name = "EndStateAssetTimeZoneAbbrev")
    String endStateAssetTimeZoneAbbrev;
    @XmlElement(name = "EndLocation")
    AssetLocation endLocation;
    @XmlElement(name = "DurationSeconds")
    long durationSeconds;
    @XmlElement(name = "WorkDefinition")
    String workDefinition;
    @XmlElement(name = "WorkingState")
    String workingState;

    @Override
    public int compareTo(AssetOperationDateInfo o) {
        if (o == null || StringUtils.isEmpty(o.getStartStateUtc())) {
            return -1;
        }
        return LocalDateTime.parse(adjustReceivedDate(getEndStateUtc()), ISO8601_FORMAT).compareTo(LocalDateTime.parse(adjustReceivedDate(o.getEndStateUtc()), ISO8601_FORMAT));
    }

    private String adjustReceivedDate(String dateToAdjust) {
        String adjustedDate = dateToAdjust;
        if (!adjustedDate.endsWith("Z")) {
            adjustedDate += "Z";
        }
        return adjustedDate;
    }

    public LocalDateTime getLocalDateToReport() {
        return LocalDateTime.parse(adjustReceivedDate(getEndStateAssetLocalTime()), ISO8601_FORMAT);
    }

    public double getCalculatedSpeed() {
        return getCalculatedDistance() / ((float) durationSeconds / 3600);
    }

    private double getCalculatedDistance() {
        return distance(Double.parseDouble(startLocation.latitude), Double.parseDouble(startLocation.longitude), Double.parseDouble(endLocation.latitude), Double.parseDouble(endLocation.longitude));
    }

    private double distance(double lat1, double lon1, double lat2, double lon2) {
        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;
        dist = dist * 1.609344;
        return (dist);
    }

    private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    private double rad2deg(double rad) {
        return (rad * 180.0 / Math.PI);
    }
}
