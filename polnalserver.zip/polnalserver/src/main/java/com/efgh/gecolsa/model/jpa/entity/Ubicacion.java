package com.efgh.gecolsa.model.jpa.entity;

import com.efgh.gecolsa.model.jpa.entity.Enums.Direction;
import com.efgh.gecolsa.model.jpa.entity.Enums.SentStatus;
import com.efgh.gecolsa.model.jpa.entity.validation.Decimal;
import com.efgh.gecolsa.model.jpa.entity.validation.Numeric;
import com.efgh.gecolsa.model.jpa.entity.validation.ValidIp;
import com.efgh.gecolsa.model.jpa.entity.validation.ZeroOrOne;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
@Entity(name = "ubicacion")
public class Ubicacion {

    @Id
    @Numeric(maxLength = 20)
    @Column(name="id_trama")
    String id_trama;

    @Column(name="tipo_transmision")
    String tipo_transmision;

    @Decimal(maxValue = -66)
    @Column(name="longitud")
    String longitud;

    @Decimal(minValue = -5)
    @Column(name="latitud")
    String latitud;

    @Decimal
    @Column(name="velocidad")
    String velocidad;

    @Column(name="direccion")
    Direction direccion;

    @NotNull
    @Column(name="fechaGPS")
    LocalDateTime fechaGPS;

    @Numeric
    @Column(name="evento")
    String evento;

    @ZeroOrOne
    @Column(name="ignicion")
    String ignicion;

    @ValidIp
    @Column(name="pip")
    String pip;

    @Numeric(maxLength = 5)
    @Column(name="puerto")
    String puerto;

    @NotNull
    @Column(name = "estado")
    String estado;

    @NotNull
    @Column(name = "estado_envio")
    SentStatus estadoEnvio = Enums.SentStatus.P;

    @Numeric
    @Column(name="odometro")
    String odometro;

    @NotNull
    @ManyToOne
    @JoinColumn(name="id_unidad")
    UnidadRastreo unidad;
}
