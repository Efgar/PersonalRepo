package com.efgh.gecolsa.model.jpa.entity;

import com.efgh.gecolsa.model.jpa.entity.Enums.Direction;
import com.efgh.gecolsa.model.jpa.entity.Enums.SentStatus;
import com.efgh.gecolsa.model.jpa.entity.validation.*;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
@Entity(name = "ubicacion")
public class Ubicacion {

    @Id
    @Numeric(maxLength = 20)
    @Column(name="id_trama")
    String id_trama;

    @Column(name="tipo_transmision")
    String tipo_transmision;

    @Decimal(maxValue = -66)
    @Column(name="longitud")
    String longitud;

    @Decimal(maxValue = -5)
    @Column(name="latitud")
    String latitud;

    @Numeric
    @Column(name="velocidad")
    String velocidad;

    @Column(name="direccion")
    Direction direccion;

    @NotNull
    @Column(name="fechaGPS")
    LocalDate fechaGPS;

    @Numeric
    @Column(name="evento")
    String evento;

    @ZeroOrOne
    @Column(name="ignicion")
    String ignicion;

    @ValidIp
    @Column(name="pip")
    String pip;

    @Numeric(maxLength = 5)
    @Column(name="puerto")
    String puerto;

    @NotNull
    @Column(name="status")
    SentStatus status = Enums.SentStatus.S;

    @Numeric
    @Column(name="odometro")
    String odometro;

    @NotNull
    @ManyToOne
    @JoinColumn(name="id_unidad")
    UnidadRastreo unidad;
}
