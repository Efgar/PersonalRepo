# POLNAL Server

El objetivo de este proyecto es obtener informacion de geolocalizacion de multiples vehiculos de la compañia para posteriormente enviarlos a los servidores de la policia nacional de colombia.

