package com.efgh.avraelayout.ui.tabs;

public class Attacks {
}
